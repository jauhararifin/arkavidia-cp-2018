#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
	int a;
	cin>>a;
	for(int i=0;i<a;i++)
	{
		long long int z,c=0;
		cin>>z;
		long long int x[z];
		for(int q=0;q<z;q++)
		{
			cin>>x[q];
		}
		sort(x,x+z);
		for(int q=1;q<z;q++)
		{
			c=c+(x[q]-x[0]);
		}
		cout<<c<<endl;
	}
}

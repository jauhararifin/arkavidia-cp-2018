#include <bits/stdc++.h>
using namespace std;
long long data[100005];
int main()
{
    long long t,n;
    cin>>t;
    while(t--)
    {
        long long temp = 1000000;
        long long ans = 0;
        memset(data,0,sizeof(data));
        cin>>n;
        for(int i=0;i<n;i++)
        {
            cin>>data[i];
            temp=min(data[i],temp);
            ans+=data[i];
        }
        ans-=(temp*n);
        cout<<ans<<endl;
    }
    return 0;
}

#include<bits/stdc++.h>

int main(){
	int t, n;
	long long int a[100005], min = 1000005;
	int i, j;
	long long int total = 0;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		total = 0;
		min = 1000005;
		scanf("%d",&n);
		for(j=0;j<n;j++){
			scanf("%lld",&a[j]);
			if(min > a[j]){
				min = a[j];
			}
		}
		for(j=0;j<n;j++){
			total += (a[j]-min);
		}
		printf("%lld\n",total);
	
	}
	
	return 0;
}

#include <iostream>
using namespace std;
int main(){
	int a;
	cin>>a;
	long long int b;
	for(int i=0;i<a;i++){
		cin>>b;
		long long int d[b];
		long long int c;
		long long int n=0;
		for(int j=0;j<b;j++){
			cin>>d[j];
			if(j==0){
				c=d[j];
			}
			n+=d[j];
			if(d[j]<c){
				c=d[j];
			}
		}
			cout<<n-(b*c)<<endl;
		}
	}
	
	


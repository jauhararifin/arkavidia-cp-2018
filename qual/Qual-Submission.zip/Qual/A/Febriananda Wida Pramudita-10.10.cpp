#include<bits/stdc++.h>
using namespace std;

#define ll long long

int main() {
	int tes, n;
	ll mini, A, sum;
	scanf("%d", &tes);
	while(tes--) {
		mini = LLONG_MAX;
		sum = 0;
		scanf("%d", &n);
		for(int i = 0; i < n; i++) {
			scanf("%lld", &A);
			mini = min(mini, A);
			sum += A;
		}
		printf("%lld\n", sum - mini * n);
	}
}
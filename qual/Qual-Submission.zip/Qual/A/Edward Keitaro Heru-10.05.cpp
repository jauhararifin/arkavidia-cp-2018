#include<bits/stdc++.h>

using namespace std;
typedef long long ll;
#define mp make_pair
#define pb push_back
#define pob pop_back
#define fi first
#define se second

int main(){
	int t;
	cin>>t;
	while(t--){
		int n;
		cin>>n;
		ll mn=1000005,tot=0,x;
		for(int i=0; i<n; i++){
			cin>>x;
			mn=min(x,mn);
			tot+=x;
		}
		cout<<tot-mn*n<<endl;
	}
	return 0;
}

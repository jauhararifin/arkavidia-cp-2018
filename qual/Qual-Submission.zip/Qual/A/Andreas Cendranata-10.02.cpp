#include<bits/stdc++.h>
using namespace std;
#define ll long long

int tc;
int n;
int a[100005];

int main()
{
	scanf("%d",&tc);
	while(tc--)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
		}
		sort(a+1,a+n+1);
		ll ans=0LL;
		for(int i=1;i<=n;i++)
		{
			ans+=a[i]-a[1];
		}
		printf("%lld\n",ans);
	}
 	return 0;
}


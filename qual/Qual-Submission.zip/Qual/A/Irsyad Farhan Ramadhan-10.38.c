#include <stdio.h>
#include <stdlib.h>

int main()
{
	int T;
	int i;
	scanf("%d",&T);
	while(T--){
		int n;
		scanf("%d",&n);
		long long mini,sum = 0,a;
		for(i = 0 ; i < n ; i++){
			scanf("%lld",&a);
			if(i == 0) mini = a;
			else if(a<mini) mini = a;
			sum += a;
		}
		printf("%lld\n",sum-(mini*n));
	}
	return 0;
}



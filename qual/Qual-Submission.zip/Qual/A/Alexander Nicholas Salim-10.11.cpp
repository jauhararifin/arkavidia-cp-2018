#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<string> vs;
#define pb(x) push_back(x)
#define PI 3.14159
#define INF 1e9+7

int gcd(int a, int b){
	if(b == 0) return a;
	return (b, a%b);
}

int lcm(int a, int b){
	return (a * (b / gcd(a, b)));
}

int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	ll t, n, x, minV, tot;
	
	cin >> t;
	for(int i = 0; i < t; i++){
		tot = 0;
		minV = numeric_limits<ll>::max();
		cin >> n;
		for(int j = 0; j < n; j++){
			cin >> x;
			tot += x;
			if(x < minV) minV = x;
		}
		cout << tot-(minV * n) << endl;
	}

	return 0;
}


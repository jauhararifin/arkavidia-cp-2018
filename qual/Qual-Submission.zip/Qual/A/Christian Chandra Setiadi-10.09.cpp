#include <iostream>

using namespace std;

int main() {
    int tc;
    long long int A, AMin, total, N;
    long long int ans;
    cin>>tc;
    for(;tc;tc--){
        cin>>N;
        total=0;
        cin>>A;
        AMin=A;
        total+=A;
        for(int i=0;i<N-1;i++){
            cin>>A;
            total+=A;
            if(A<AMin)AMin=A;
        }
        ans=total-AMin*N;
        cout<<ans<<endl;
    }
}

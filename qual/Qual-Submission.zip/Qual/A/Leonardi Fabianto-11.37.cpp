#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    int m;
    cin>>n;

    int i;
    int a;
    vector <int> x;
    int p;
    long sum;
    while(n--){
        sum = 0;
        p = 9999999;
        cin>>m;
        for(i = 0; i < m; i++){
            cin>>a;
            x.push_back(a);
            if(x[i] < p) p = x[i];
        }
        for(i = 0; i < m; i++){
            sum += x[i] - p;
        }
        x.resize(0);
        cout<<sum<<'\n';
        }
    return 0;
}

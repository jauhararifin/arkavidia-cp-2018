#include <stdio.h>

int main(){
	long long int tc, n, min, sum, arr[200000];
	scanf("%lld", &tc);
	for(int i = 0; i<tc; i++){
		sum = min = 0;
		scanf("%lld", &n);
		for(int j = 0; j<n; j++){
			scanf("%lld", &arr[j]);
			sum += arr[j];
			if(j == 0)
				min = arr[0];
			else{
				if(arr[j] < min)
					min = arr[j];
			}
		}
		
		printf("%lld\n", sum - (min * n));
	}
	return 0;
}

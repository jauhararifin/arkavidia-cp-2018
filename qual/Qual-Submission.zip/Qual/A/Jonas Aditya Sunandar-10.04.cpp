#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef pair<int,ii> iii;
const int INF=(int)2e9;
const double EPS=(double)1e-9;
const double PI=(double)acos(-1.0);
const ll MOD=(ll)1e9+7;

#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define FOR(i,a,n) for(int i=a;i<n;i++)
#define MAX 100005
#define wa cout<<"wa"<<endl;
#define LEFT 2*node
#define RIGHT 2*node+1
void base(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
}

int main(){
//	base();
	int t;
	cin>>t;
	while(t--){
		ll n,arr[MAX],smallest=INF;
		cin>>n;
		ll total=0;
		FOR(i,0,n){
			cin>>arr[i];
			smallest=min(smallest,arr[i]);
			total+=arr[i];
		}
		cout<<total-(smallest*1LL*n)<<endl;
	}
	return 0;
}



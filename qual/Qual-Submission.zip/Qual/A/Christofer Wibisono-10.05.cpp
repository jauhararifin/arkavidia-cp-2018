#include<stdio.h>
#include<string.h>

#include<iostream>
#include<string>
#include<algorithm>
#include<map>

using namespace std;

int main()
{
	
	int t,m,arr[100050],kecil;
	long long tot;
	
	cin>>t;
	while(t--)
	{
		cin>>m;
		kecil=10000000;
		tot=0;
		for(int i=0;i<m;i++)
		{
			scanf("%d",&arr[i]);
			if(arr[i]<kecil)
			{
				kecil = arr[i];
			}
		}
		for(int i=0;i<m;i++)
		{
			tot+=arr[i]-kecil;
		}
		printf("%lld\n",tot);
	}
	return 0;
}

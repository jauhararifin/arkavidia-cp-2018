#include <iostream>
using namespace std;

int main(){
	int T;
	long int N;
	cin>>T;
	for(int i=1;i<=T;i++){
		cin>>N;
		long int A[N];
		long int sum=0;
		for(int j=0;j<N;j++){
			cin>>A[j];
		}
		long int min=A[0];
		for(int j=0;j<N;j++){
			if(min>A[j]){
				min=A[j];
			}
		}
		for(int j=0;j<N;j++){
			sum=sum+(A[j]-min);
		}
		cout<<sum<<endl;
	}
}

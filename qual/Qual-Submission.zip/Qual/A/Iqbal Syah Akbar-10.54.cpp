#include<iostream>;
using namespace std;
int main(){
    long int t,n,s,m,sum,mini;
    cin>>t;
    long int res[t];
    s=t;
    for(;t>0;t--){
        cin>>n;
        m=n;
        sum=0;
        mini=-1;
        long int ll[n];
        for(;n>0;n--){
            cin>>ll[n-1];
            sum+=ll[n-1];
            if(mini==-1)mini=sum;
            else if (mini>ll[n-1])mini=ll[n-1];
        }
        sum-=mini*m;
        res[t-1]=sum;
    }
    for(;s>0;s--)if(s>1)cout<<res[s-1]<<endl;
    else cout<<res[s-1];
}

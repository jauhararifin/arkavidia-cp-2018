#include<bits/stdc++.h>
using namespace std;

const int INF = 1e9;
const int MOD = 1e9+7;
#define fi first
#define se second
#define ll long long
typedef pair<int,int> ii;
typedef pair<int,ii> iii;
int dX[]={0,0,-1,1};
int dY[]={-1,1,0,0};

int main(){
	int tc;
	scanf("%d",&tc);
	while(tc--){
		int n, arr[100001];
		scanf("%d",&n);
		int mn = 1e9;
		for(int i=0;i<n;i++){
			scanf("%d",&arr[i]);
			mn = min(mn,arr[i]);
		}
		ll res =0;
		for(int i=0;i<n;i++){
			res += arr[i]-mn;
		}
		printf("%lld\n",res);
	}
	return 0;
}

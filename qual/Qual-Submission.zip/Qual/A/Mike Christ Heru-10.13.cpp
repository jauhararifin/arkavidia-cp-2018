#include<bits/stdc++.h>

using namespace std;

int main(){
	long long temp,sum,min;
	int in,a;
	scanf("%d",&in);
	for(int i=1;i<=in;i++){
		scanf("%d",&a);
		sum=0;
		min=100000000;
		for(int j=1;j<=a;j++){
			scanf("%lld",&temp);
			sum+=temp;
			if(min>temp)min=temp;
		}
		printf("%lld\n",sum-min*a);
	}
	return 0;
}

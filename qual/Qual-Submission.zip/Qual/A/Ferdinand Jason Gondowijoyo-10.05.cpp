#include<bits/stdc++.h>
using namespace std;

int main(){
    int t;scanf("%d",&t);
    while(t--){
        int n;scanf("%d",&n);
        unsigned long long a,minimum=ULLONG_MAX,sum=0;
        for(int i=0;i<n;i++){
            scanf("%llu",&a);
            if(a<minimum) minimum=a;
            sum+=a;
        }
        printf("%llu\n",sum-(minimum*n));
    }
    return 0;
}
#include <bits/stdc++.h>
using namespace std;

int main(){
    int tc;
    scanf("%d",&tc);
    while(tc--){
        int n;
        scanf("%d",&n);
        int data[n+1];
        int mnn=INT_MAX;
        for (int i=0;i<n;i++){
            scanf("%d",data+i);
            if (data[i]<mnn){
                mnn=data[i];
            }
        }
        long long sisa=0;
        for (int i=0;i<n;i++){
            sisa+=(data[i]-mnn);
        }
        printf("%lld\n",sisa);
    }
    return 0;
}
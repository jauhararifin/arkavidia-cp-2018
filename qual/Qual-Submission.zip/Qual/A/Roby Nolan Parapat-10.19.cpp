#include <bits/stdc++.h>
#define MAX 1000000000

typedef long long ll;
using namespace std;

int main(){
	ll t,n,sm=0;
	cin >> t;
	while(t--){
		ll bil,mn=MAX;
		sm=0;
		cin >> n;
		for(ll i=0;i<n;i++){
			cin >> bil;
			sm+=bil;
			mn = min(mn,bil);
			 
		}
		cout << sm-mn*n << endl;
	}
	
	return 0;
}

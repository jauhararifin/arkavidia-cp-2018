#include <bits/stdc++.h>
using namespace std;

#define N 1000
#define M 1000
#define asd(i, a, b) for(int i=a; i<b; i++) // macro asd (variable counter, batas awal, batas akhir)
#define qasd(b) for(int i=0;i<b;i++)
#define MP make_pair
#define newl cout << "\n"
#define printMat(a,b,c) asd(i,0,a)asd(j,0,b){\
cout << c[i][j];\
if(j==b-1)newl;\
else printf("\t");}




int main() {
	long int n, m,a,min=1000000, cnt=0;
	
	cin >> n;
	asd(i, 0, n){
		cin >> m;
		asd(j, 0, m){
			cin >> a;
			if (a<min) min = a;
			cnt += a;
		}
		cout << cnt - (min*m) << endl;
		cnt = 0;
		min = 1000000;
	}
 return 0;
}



/*
int x, y, t, win=0, n;
cin >> n;
asd(r, 0, n){
	int Q[N]={0};
	cin >> x >> y;
	asd(i, 0, y)
		asd(j, 0, x){
			cin >> t;
			Q[j] += t;
		}
	asd(i, 0, x){
		if (Q[i]>Q[i-1])win = i;

	}
	cout << win+1 << "\n";
}

ICPC Meeting Probs
int q, w, e, pre=0, post=0, y, z;
int Q[N];	
	
	cin >> q >> w >> e;
	asd(i, 0, q)cin >> Q[i];
	
	if (e==0){
		if (q==w) cout << "0";
		else cout << "-1";
	}
	else if (Q[w-1]==Q[w]){
		for(z=w-1;z>0;z--){
			if (Q[w-1]==Q[z])pre++;
			else break;
		}
		if (Q[w]+1 < e){
			asd(i, w, e){
				if(Q[w]==Q[i])post++;
				else break;
			}
			cout << min(pre,post);
		}
		else cout << pre;
	}
	else cout << "0";
	
newl;

#include <bits/stdc++.h>

using namespace std;


*/
	
	

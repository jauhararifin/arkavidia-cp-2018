#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define MOD 1000000007
#define fi first
#define se second

ll modexp(ll a, ll b, ll m){
    ll res = 1;
    for(; b; b >>= 1, a = (a*a)%m)
        if(b&1) res = (res*a)%m;
    return res%m;
}

int main(){
	int t;
	ll n, a;
	scanf("%d", &t);
	while(t--){
		ll mini = 1000005, total = 0;
		scanf("%lld", &n);
		for(int i = 0; i < n; i++){
			scanf("%lld", &a);
			if(a < mini) mini = a;
			total+=a;
		}

		printf("%lld\n", total - mini*n);
	}
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int data[100005];
int main()
{
	int tc;
	scanf("%d",&tc);
	while(tc--)
	{
		int n;
		scanf("%d",&n);
		int mini=10000000;
		long long sis=0;
		for(int i=0;i<n;i++)
		{
			scanf("%d",&data[i]);
			if(mini>data[i])mini=data[i];
		}
		for(int i=0;i<n;i++)
		{
			sis+=data[i]-mini;
		}
		printf("%lld\n",sis);
	}
return 0;
}


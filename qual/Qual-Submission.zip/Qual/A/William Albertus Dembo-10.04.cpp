#include<bits/stdc++.h>

using namespace std;

int main() {
    int tt;
    scanf("%d", &tt);
    while(tt--) {
        int n;
        scanf("%d", &n);
        int arr[n+5];
        int mini = INT_MAX;
        for (int i=0;i<n;i++) {
            scanf("%d", &arr[i]);
            mini = min(arr[i], mini);
        }
        long long ans = 0;
        for (int i=0;i<n;i++) {
            ans += arr[i]-mini;
        }
        printf("%lld\n", ans);
    }
}
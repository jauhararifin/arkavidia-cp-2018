#include <bits/stdc++.h>
#define mod 1000000007
using namespace std;
long long t,n,l,r,mid,x,data[1000006],res=0;
long long jum=0;
bool sim(long long x){
    long long sum=0;
    for (int i=1; i<=n; i++){
        sum+=(data[i]/x);
        if (sum>=n) return true;
    }
    return false;
}
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>t;
    for (int i=1; i<=t; i++){
        cin>>n;
        res =1000000000;
        jum=0;
        for (int j=1; j<=n; j++){
            cin>>data[j];
            jum+=data[j];
            res = min(res,data[j]);
        }
        cout<<jum-res*n<<"\n";
    }    
}
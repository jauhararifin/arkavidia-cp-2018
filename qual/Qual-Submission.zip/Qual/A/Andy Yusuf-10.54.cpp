#include <iostream>
#include <cstdio>

#define ull unsigned long long

using namespace std;

int main(){
    int t, n, j;
    ull inp, minn = 0, sum;
    cin >> t;
    while (t--){
        scanf("%d", &n);
        sum = 0;
        for (j=1;j<=n;j++){
            cin >> inp;
            if (j == 1){
                minn = inp;
            }
            else{
                minn = min(minn, inp);
            }
            sum += inp;
        }
        minn *= n;
        cout << sum - minn << "\n";
    }
    return 0;
}

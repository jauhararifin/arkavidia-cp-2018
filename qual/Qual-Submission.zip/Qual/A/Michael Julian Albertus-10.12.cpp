#include<stdio.h>

int main(){
    int tc;
    long long int a,b;
    scanf("%d",&tc);
    while(tc--){
        int banyak;
        a=0;
        long long int mini=1000000000;
        int temp;
        scanf("%d",&banyak);
        for(int i=0;i<banyak;i++){
            scanf("%d",&temp);
            a+=temp;
            if(temp<mini) mini=temp;
        }
        mini=mini*banyak;
        printf("%lld\n",a-mini);
    }
    return 0;
}
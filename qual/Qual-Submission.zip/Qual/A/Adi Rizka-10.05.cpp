#include <bits/stdc++.h>
using namespace std;

int main()
{
	int t; cin >> t;
	while(t--) {
		int n; cin >> n;
		int x[n+7]; int mini = INT_MAX;
		for(int i=0; i<n; i++) {
			cin >> x[i];
			mini = min(mini, x[i]);
		}
		long long ans = 0;
		for(int i=0; i<n; i++) {
			ans += (x[i] *1LL - mini*1LL);
		}
		cout << ans << "\n";
	}
}

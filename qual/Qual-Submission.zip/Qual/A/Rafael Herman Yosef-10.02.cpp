#include<stdio.h>
#include<sstream>
#include<iostream>

#include<math.h>
#include<algorithm>
#include<utility>
#include<string.h>
#include<string>
#include<stdlib.h>
#include<assert.h>
#include<time.h>

#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>

#define FI first
#define SE second
#define PB push_back
#define MP make_pair
#define endl '\n'
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

void desperate_optimization(int precision){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(precision);
}

int main(){
	desperate_optimization(10);
	int ntc;
	cin>>ntc;
	while(ntc--){
		int n;
		cin>>n;
		ll tot = 0;
		ll mini = 1e18;
		for(int i=0;i<n;i++){
			ll x;
			cin>>x;
			tot += x;
			mini = min(mini,x);
		}
		cout<<tot-n * mini<<endl;
	}
	return 0;
}


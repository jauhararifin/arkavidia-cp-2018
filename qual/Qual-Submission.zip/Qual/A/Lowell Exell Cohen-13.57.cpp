#include<iostream>

using namespace std;

int main()
{
	long long T, N, cake, value=0, min;
	
	cin >> T;
	for(int i=0;i<T;i++)
	{
		min = 1000000;
		value = 0;
		cin >> N;
		for(int j=0;j<N;j++)
		{
			cin >> cake;
			value = value + cake;
			if(cake < min) min = cake;
		}
		value = value -(min*N);
		cout << value << endl;
	}
	return 0;
}

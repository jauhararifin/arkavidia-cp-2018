#include <iostream>
using namespace std;

int main (){
	int T,n=0;
	long int N;
	cin >> T;
	do {
		long int sum= 0;
		cin >> N;
		long int A [N];
	
		for (int i=0;i<N;i++){
			cin >> A[i];
		}
		long int min = A[0];		
		for (int i=0;i<N;i++){
			if (min > A[i]){
				min = A[i];
			}
		}
		for (int i=0;i<N;i++){
			A[i] = A[i]-min;
			sum += A[i];
		}
		cout << sum <<endl;

		n++;		
	}while (n<T);
}
#include <stdio.h>

int main(){
	int tc,i;
	long int n,x,min,j,total,req;
	
	scanf("%d",&tc);
	for(i=0;i<tc;i++){
		scanf("%ld",&n);
		total=0;
		for(j=0;j<n;j++){
			scanf("%d",&x);
			total = total+x;
			if(j==0){
				min=x;
			}else{
				if(min>x){
					min=x;
				}
			}
		}
		req = total/n;
		if(min<=req){
			total = total-min*n;
		}else{
			total = total-req*n;
		}
		printf("%ld\n",total);
	}
}

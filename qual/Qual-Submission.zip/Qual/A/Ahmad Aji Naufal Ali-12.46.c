/* ====================================================
Program 		: TeksAlay_ahmadajinaufalali.c
Deskripsi		: Membuat teks alay
Author 			: ahmadajinaufalali
Versi/Tanggal	: 1.00 / 1 Nov 2017
Compiler		: Dev C++
============================================================ */
#include <stdio.h>
#include <string.h> //mencegah warning akibat perintah strlen(teks);

int main()
{
/*DEKLARASI & INISIALISASI */
	
	int t, i;
	long n, a, small, j, temp;
	long long sum;

	scanf("%d", &t);
	i = 0;
	while (i < t)
	{
		scanf("%ld", &n);
		scanf("%ld", &a);
		small = a; //assign first
		sum = a;
		j = 1;
		while(j < n)
		{
			scanf("%ld", &a);
			sum += a;
			if (small > a)
			{
				small = a;
			}
		j++;
		}

	small *= n;
	sum -= small; 
	printf("%lld\n", sum);

	i++;
	}



return 0;
}

#include <bits/stdc++.h>
using namespace std;

bool IsPrime(int x)
{
	if (x==1) return false;
	int akar=(int)sqrt(x);
	for (int i=2;i<=akar;i++)
	{
		if (x%i==0) return false;
	}
	return true;
}

int main()
{
//	freopen("input.txt","r",stdin);
	long long t;
	cin>>t;
	while (t--)
	{
		long long k;
		long long tab[100010];
		long long mn=1e9;
		cin>>k;
		for (long long i=1;i<=k;i++)
		{
			cin>>tab[i];
			mn=min(tab[i],mn);
		}
		long long ans=0;
		for (int i=1;i<=k;i++)
		 ans+=tab[i]-mn;
		cout<<ans<<"\n"; 
	}
}

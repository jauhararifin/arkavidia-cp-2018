#include <bits/stdc++.h>
using namespace std;

int TC;
long long n, x, mini, total;

int main() {
    scanf("%d", &TC);
    while (TC--) {
        mini = 10000000;
        total = 0;
        scanf("%lld", &n);
        for (int i = 0; i < n; i++) {
            scanf("%lld", &x);
            total += x;
            mini = min(mini, x);
        }
        long long ans = total - n * mini;
        printf("%lld\n", ans);
    }
}
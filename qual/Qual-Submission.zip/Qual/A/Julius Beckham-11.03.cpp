#include<bits/stdc++.h>

using namespace std;

#define SIZE 100005

int main (){
	
	int T, N;
	long long int A[SIZE];
	long long int min;
	long long int sum;
	
	cin>>T;
	while(T--){
		sum=0;
		cin>>N;
		for(int i=0;i<N;i++){
			cin>>A[i];
			if(i==0) min=A[0];
			sum+=A[i];
			if(min>A[i]) min=A[i];
		}
		sum=sum-(min*N);
		cout<<sum<<endl;
	}
	
	return 0;
}

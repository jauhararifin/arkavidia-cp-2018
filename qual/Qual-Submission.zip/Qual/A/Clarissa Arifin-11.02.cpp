#include <stdio.h>
int main (){
	long long int tc;
	scanf("%lld",&tc);
	while(tc--){
		long long int n;
		scanf("%lld",&n);
		long long int total=0,anak[n],temp=1000000;
		for(int i=0;i<n;i++){
			scanf("%lld",&anak[i]);
			if(temp>anak[i]) temp=anak[i];
		}
		for(int i=0;i<n;i++){
			total+=(anak[i]-temp);
		}
		printf("%lld\n",total);
	}
}

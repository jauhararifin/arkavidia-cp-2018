#include <iostream>

using namespace std;

int main()
{
    int t;
    long n;

    cin >> t;
    long a[100000];
    long min = 9999999;
    long total = 0;
    

    for (int i = 0; i < t; i++)
    {
        cin >> n;
        for (int j = 0; j < n; j++)
        {
            cin >> a[j];

            if (a[j] < min)
            {
                min = a[j];
            }
        }

        for (int j = 0; j < n; j++)
        {
            a[j] = a[j] - min;
            total = total + a[j];
        }

        cout << total << endl;
        total = 0;
        min = 9999999;
    }

    return 0;
}
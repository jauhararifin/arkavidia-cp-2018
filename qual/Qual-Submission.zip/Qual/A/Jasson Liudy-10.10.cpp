#include<bits/stdc++.h>
#define INF 1000000000
#define pii pair<int, int>
#define fi first
#define se second
#define pb push_back
#define ll long long
using namespace std;

int main()
{
	int tc;
	cin>>tc;
	for(int ntc=0;ntc<tc;ntc++)
	{
		ll data, mini=10000000000000;
		ll total=(ll)0;
		scanf("%lld", &data);
		for(int a=0;a<data;a++)
		{
			ll inp;
			scanf("%lld", &inp);
			total+=inp;
			mini=min(mini, inp);
		}
		cout<<total-(ll)((ll)data*(ll)mini)<<endl;
	}
 	return 0;
}


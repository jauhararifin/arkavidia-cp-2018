#include <stdio.h>
#include <string>
#include <string.h>
#include <iostream>
#include <algorithm>
#include <stdlib.h>
#include <queue>
#include <vector>
#include <stack>
#include <limits.h>
#include <map>
using namespace std;
#define mp make_pair
#define fi first
#define se second
#define pb push_back
#define ll long long int
#define ull unsigned long long int
int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        ll n;
        scanf("%lld",&n);
        ll arr[100005],mini=INT_MAX;
        for(int a=0;a<n;a++){
            scanf("%lld",&arr[a]);
            mini=min(mini,arr[a]);
        }
        ll ans=0;
        for(int a=0;a<n;a++){
            ans+=arr[a]-mini;
        }
        printf("%lld\n",ans);
    }
    return 0;
}

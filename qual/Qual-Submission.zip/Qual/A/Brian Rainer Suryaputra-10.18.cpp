#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
	ll t,a,x,min,sum;
	scanf("%lld",&t);
	while(t--){
		scanf("%lld",&a);
		min=INT_MAX;
		sum=0;
		for(int i=0;i<a;i++){
			scanf("%lld",&x);
			if(min>x) min=x;
			sum+=x;
		}
		if(a*min > sum) cout<<0<<endl;
		else cout<<sum-(a*min)<<endl;
	}
	return 0;
}

x = int(input())
for i in range(x):
    s = input().split()
    jum = int(s[0])
    h = 0
    kec = 1000001
    for j in s[1:]:
        a = int(j)
        h += a
        if(a < kec): kec = a
    print(h-(jum*kec))

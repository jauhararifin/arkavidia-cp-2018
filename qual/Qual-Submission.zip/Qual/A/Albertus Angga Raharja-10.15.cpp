#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef pair<double, double> pdd;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<pii> vii;

#define newline '\n';
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define FAST_IO  ios_base::sync_with_stdio(false)

const int PI = acos(-1.0);
const int MOD = 1e9 + 7;

ll power(ll a, int b) {
	if (b == 0) return 1LL;
	if (b == 1) return a % MOD;
	ll ret = power(a, b / 2) % MOD;
	ret = (ret * ret) % MOD;
	if (b & 1) ret = (ret * a) % MOD;
	return ret;
}

void tests() {
	assert(power(2LL, 10) == 1024);
	assert((10LL & 1) == 0);
}

void solve() {
	int N;
	cin >> N;
	ll jum = 0LL;
	ll minimum = 1e7;
	for (int i = 0; i < N; ++i) {
		ll baca;
		cin >> baca;
		minimum = min(minimum, baca);
		jum += baca;
	}
	cout << (jum - (minimum * (ll)N)) << '\n';
}

int main() {
	FAST_IO;

	// tests();

	int tc;
	cin >> tc;
	while (tc--) {
		solve();
	}

	return 0;
}

#include <bits/stdc++.h>

using namespace std;

#define sf scanf
#define pf printf


int main(){
    int t;
    long long i,n,data,jum,mini;
    cin>>t;
    while(t--){
        cin>>n;
        //tempn=n;
        cin>>mini;
        jum = mini;
        for(i=2;i<=n;i++){
            cin>>data;
            jum = jum + data;
            if(mini>=data) mini = data;
        }
        jum = jum - (mini*n) ;
        //long long pemb = 1e9+7;
        cout<<jum<<endl;
    }
 return 0;
}

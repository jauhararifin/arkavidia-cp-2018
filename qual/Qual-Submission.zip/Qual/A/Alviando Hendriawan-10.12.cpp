#include<stdio.h>
#include <iostream>

using namespace std;
int main(){
	int tc;
	cin >> tc;
	for (int i = 0; i < tc; i++){
		int n;
		cin >> n;
		long long total = 0;
		long long min;
		cin >> min;
		total+= min;
		for (int j = 0; j < n-1; j++){
			int temp;
			cin >> temp;
			total+= temp;
			if ( min > temp) min = temp;
		}
		printf("%lld\n", total - min * n);
		
	}	
	
	
	
	
	return 0;
}

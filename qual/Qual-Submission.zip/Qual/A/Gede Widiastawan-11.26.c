#include<stdio.h>

int main() {
    int t,i;
    long int result,n,a,temp,total,j;
    scanf("%d",&t);
    for(i=1;i<=t;i++) {
        scanf("%ld",&n);
        total = 0;
        a = 0;
        temp = 0;
        for(j=1;j<=n;j++) {
            scanf("%ld",&temp);
            if(a==0) {
                a = temp;
            }else if(a>temp) {
                a = temp;
            }
            total+=temp;
        }
        result = total - (a*n);
        printf("%ld\n",result);
    }
    return 0;
}

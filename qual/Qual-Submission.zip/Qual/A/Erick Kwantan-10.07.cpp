#include <bits/stdc++.h>

using namespace std;

int main () {
    int n;
    long long int a, b, mini, total;

    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> a;
        total = 0;
        mini = 1000005;
        for(int j = 0; j < a; j++) {
            cin >> b;
            total += b;
            mini = min(mini, b);
        }
        cout << total - a * mini << endl;
    }
}

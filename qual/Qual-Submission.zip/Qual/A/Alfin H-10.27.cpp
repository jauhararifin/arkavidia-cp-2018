#include<bits/stdc++.h>
using namespace std;
int main()
{
	int tc;
	long long int n,a;
	scanf("%d",&tc);
	while(tc--)
	{
		long long int total = 0;
		long long int min = 1000001;
		scanf("%d",&n);
		for(int i=0;i<n;i++)
		{
			scanf("%d",&a);
			total += a;
			if(a<min)min = a;
		}
		printf("%lld\n",total-(n*min));
	}
}

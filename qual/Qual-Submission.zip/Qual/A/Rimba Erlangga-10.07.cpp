#include <bits/stdc++.h>
#define ll long long
using namespace std;

int T, N;
ll a[100010];

int main() {
	cin >> T;
	while(T--) {
		cin >> N;
		ll mini = 1000000, sum = 0;
		for(int i = 0; i < N; i++) {
			cin >> a[i];
			if(a[i] < mini) mini = a[i];
			sum += a[i];
		}
		
		cout << sum-(N*mini) << endl;
	}
	
		
	return 0;
}

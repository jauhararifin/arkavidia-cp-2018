#include<iostream>
using namespace std;
int min(long int A[],long int n){
	long int mins=A[0];
	for(int i=1;i<n;i++){
		if(A[i]<=mins){
			mins=A[i];
		}
	}
	return mins;
}

int main(){
	int T,N;
	long int jawab;
	cin>>T;
	while(T>0){
		cin>>N;
		if(N>0){
			long int sum=0,A[N];
			for(int i=0;i<N;i++){
				cin>>A[i];
				if(A[i]>0){
					sum+=A[i];
				}
			}
			long int mini=min(A,N);
			jawab=sum-(mini*N);
			cout<<jawab<<endl;
		}
			T--;
	}
	return 0;
}

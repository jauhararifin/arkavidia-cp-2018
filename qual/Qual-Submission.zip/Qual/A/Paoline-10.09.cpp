#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

typedef vector<int> vi;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef vector<pii> vii;

#define mp make_pair
#define fi first
#define se second

#define pb push_back
#define pob pop_back
#define pf push_front
#define pof pop_front

#define FOR(i,n) for(int i=0;i<n;i++)
#define REPP(i,l,r,c) for(int i=l;i<=r;i+=c)
#define REP(i,l,r) REPP(i,l,r,1)

#define FORD(i,n) for(int i=n-1;i>=0;i--)
#define REVV(i,l,r,c) for(int i=max(l,r),_m=min(l,r);i>=_m;i-=c)
#define REV(i,l,r) REVV(i,l,r,1)

int a[100010];
int main(){
	int tc; cin>>tc;
	while(tc--){
		int n; ll ans=0;
		cin>>n;
		FOR(i,n)cin>>a[i];
		sort(a, a+n);
		REP(i,1,n-1){
			ans+=a[i]-a[0];
		}
		cout<<ans<<endl;
	}
	return 0;
}

#include<iostream>
using namespace std;

long long aa[100005];

int main() {
	long long a,b,c,d,e,f,g;
	cin >> a;
	for (b=1;b<=a;b++) {
		cin >> c;
		f=0;
		for (d=1;d<=c;d++) {
			cin >> aa[d];
			f=f+aa[d];
			if (d==1) {
				e=aa[d];
			}
			else {
				if (e>aa[d]) {
					e=aa[d];
				}
			}
		}
		cout << f-(c*e) << "\n";
	}
}

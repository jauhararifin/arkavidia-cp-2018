#include <stdio.h>

int main(){
	int tc;
	scanf("%d", &tc);
	while(tc--){
		long long int n, min=2000000, temp, tot=0;
		scanf("%lld", &n);
		for(int i=0; i<n; i++){
			scanf("%lld", &temp);
			if(temp<min){
				min=temp;
			}
			tot+=temp;
		}
		
		tot-=(min*n);
		printf("%lld\n", tot);
	}
	
	
	return 0;
}

#include<stdio.h>
#include<math.h>
#include<string.h>

int main() {
    long long int kue[100100], mn, jwb, tc, n;

    scanf("%lld", &tc);
    for(int t=0;t<tc;t++) {
        scanf("%lld", &n);
        mn = 9999999;
        for(int i=0;i<n;i++){
            scanf("%lld", &kue[i]);

            if(kue[i]<mn) mn = kue[i];
        }

        jwb = 0;

        for(int i=0;i<n;i++) {
            jwb+=(kue[i]-mn);
        }
        printf("%lld\n", jwb);
    }
    return 0;
}

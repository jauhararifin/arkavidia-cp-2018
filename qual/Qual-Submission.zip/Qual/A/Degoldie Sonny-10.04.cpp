#include <bits/stdc++.h>
using namespace std;

int main(){
	int qt;
	scanf("%d", &qt);

	for (int q = 0; q < qt; q++){
		int n;
		scanf("%d", &n);

		long long total = 0;
		long long minim = 1000000;
		for (int i = 0; i < n; i++){
			long long x;
			scanf("%lld", &x);

			total+= x;
			minim = min(minim, x);
		}

		printf("%lld\n", total - minim*n);
	}
}
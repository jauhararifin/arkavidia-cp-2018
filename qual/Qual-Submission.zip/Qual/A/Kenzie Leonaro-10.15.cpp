#include <stdio.h>

int main(){
	int T;
	long long int N,A[100000],min=9999999,total=0;
	scanf("%d",&T);
	while(T--){
		scanf("%lld",&N);
		for(long long int i=0;i<N;i++){
			scanf("%lld",&A[i]);
			total+=A[i];
			if(A[i]<min) min=A[i];
		}
		printf("%lld\n",total-min*N);
		total =0 ; min = 9999999;
	}
}

// Bismillahirohmanirohiim

#include<bits/stdc++.h>
using namespace std;

#define nl "\n"
#define PB push_back
#define SZ size()
#define ios ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL)
#define MP make_pair
#define LEN length()

int main()
{
    ios;
    long long int t,n ;
    cin >> t ;
    while(t--)
    {
        long long int ans = 0,x;
        long long int mini= INT_MAX ;
        cin >> n ;
        for(int i=0;i<n;i++)
        {
            cin >> x;
            ans+=x;
            if(x<mini) mini=x;
        }
        cout << ans-(mini*n) << nl ;
    }
}

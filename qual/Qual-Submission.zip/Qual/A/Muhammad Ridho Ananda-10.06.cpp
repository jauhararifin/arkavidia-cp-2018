#include <bits/stdc++.h>

#define fi first
#define se second
#define sz(a) (int)(a).size()
#define all(a) (a).begin(), (a).end()
#define reset(a, v) memset((a), v, sizeof (a))

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef vector<ii> vii;

const int N = 100005;

int n;
int dat[N];

int main() {
	int tc; scanf("%d", &tc);
	while (tc--) {
		scanf("%d", &n);
		int mini = INT_MAX;
		ll sum = 0;
		for (int i = 0; i < n; ++i) {
			scanf("%d", &dat[i]);
			mini = min(mini, dat[i]);
			sum += dat[i];
		}
		printf("%lld\n", sum - 1ll*n*mini);
	}
	return 0;
}
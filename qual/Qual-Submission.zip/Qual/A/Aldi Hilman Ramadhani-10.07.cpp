#include <bits/stdc++.h>
using namespace std;

long long t,n,i,ans;
int main(){
  cin >> t;
  while(t--){
    cin >> n;
    long long ar[n+10];
    long long dikit = 4e+18;
    for (i = 0; i < n; i++){
      cin >> ar[i];
      dikit = min(dikit,ar[i]);
    }
    ans = 0;
    for (i = 0; i < n; i++){
      ans += abs(dikit-ar[i]);
      // cout << ans << endl;
    }
    cout << ans << endl;
  }
}

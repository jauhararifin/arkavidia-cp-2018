#include<bits/stdc++.h>
#define loop(a,b,c) for(int a=b;a<c;a++)
#define fi first
#define se second
#define mp make_pair
#define all(v) v.begin(),v.end()
#define pb push_back
#define sz(v) v.size()
using namespace std;
typedef long long LL;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef pair<int,ii> iii;
typedef vector<iii> viii;
const double PI=2*acos(0);
const LL MOD=1000*1000*1000+7;
//templates ends here

int main(){
    int T;
    //ios_base::sync_with_stdio(false);
    //cin.tie(NULL);
    cin>>T;
    while(T--){
        LL a,N;
        LL kue=INT_MAX;
        LL total=0;
        cin>>N;
        loop(i,0,N){
            cin>>a;
            kue=min(kue,a);
            total+=a;
        }
        cout<<total-(kue*N)<<"\n";
    }
}

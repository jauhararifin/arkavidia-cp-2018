#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

int main()
{
	long long int arr[100010],n,i,min,total;
	int t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%lld",&n);
		min = -1;
		for(i=0;i<n;i++)
		{
			scanf("%lld",&arr[i]);
			if(min == -1)
			min = arr[i];
			else if(arr[i] < min)
			min = arr[i];
		}
		total = 0;
		for(i=0;i<n;i++)
		{
			total += arr[i]-min;
		}
		printf("%lld\n",total);
	}
	return 0;
}

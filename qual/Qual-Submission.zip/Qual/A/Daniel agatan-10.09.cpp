#include<bits/stdc++.h>
using namespace std;

int main() 
{
	int tc=0;
	cin>>tc;
	
	
	while(tc--)
	{
	    
	    long long int n;
	    cin>>n;
	    int cake[1000001]={0};
	    long long int min=0;
	    for(int i=0;i<n;i++)
	    {
	        cin>>cake[i];
	        
	        if(i==0)
	        min=cake[i];
	        
	        else if(cake[i]<min)
	        {
	           min=cake[i];
	        }
	    }
	    
	    long long int count=0;
	    
	    for(int i=0;i<n;i++)
	    {
	        count+=(cake[i]-min);
	    }
	    
	    cout<<count<<endl;
	    
	}
	
	
}


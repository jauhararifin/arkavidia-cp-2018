#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

template <typename T>
T G(){
    T res=0;char c;
    bool minus=false;
    while(1){
        c=getchar_unlocked();
        if(c==' '||c=='\n') continue;
        if(c=='-')minus=true;
        else break;
    }res=c-'0';
    while(1){
        c=getchar_unlocked();
        if(c>='0'&& c<='9') res=10*res+c-'0';
        else break;
    }return (minus)? -res : res;
}


int main()
{
	int tc;
	tc = G<int>();
	while(tc--){
		ll n = G<ll>();
		long long arr[n],min = 1000010,res=0;
		for(int i=0;i<n;++i){
			arr[i] = G<ll>();
			if(arr[i] < min)min = arr[i];
		}
		for(int i=0;i<n;++i){
			res+=(arr[i]-min);
		}
		printf("%lld\n",res);
	}
	return 0;
}
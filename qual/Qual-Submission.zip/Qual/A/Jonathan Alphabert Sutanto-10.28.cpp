#include<stdio.h>


int main(){
	int T;
	scanf("%d", &T);
	while(T--){
		int N;
		scanf("%d", &N);
		int pot[N];
		scanf("%d", &pot[0]);
		int min=pot[0];
		for(int i=1; i<N; i++){
			scanf("%d", &pot[i]);
			if(min>pot[i]){
				min=pot[i];
			}
		}
		long long int hasil=0;
		for(int i=0; i<N; i++){
			hasil+=(pot[i]-min);
		}
		
		printf("%lld\n", hasil);
	}
	
	return 0;
}

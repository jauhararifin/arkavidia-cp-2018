#include<stdio.h>
#include<math.h>
#include<string.h>
#include<ctype.h>


int main()
{
	long long a ,b ,c,d,e,f,g,j,t;
		long long arr[200000];
			scanf("%lld",&t);
				for(b =1; b<= t; b++)
				{
					scanf("%lld",&a);
					long long min =1000001;
					long long hasil = 0;
						for(c = 1; c<= a; c++)
						{
							scanf("%lld",&arr[c]);
							if(arr[c] < min)
							{
								min = arr[c];
							}
						}
						for(c = 1; c<= a; c++)
						{
							hasil = hasil + (arr[c] - min);
						}
						printf("%lld\n",hasil);
				}
}

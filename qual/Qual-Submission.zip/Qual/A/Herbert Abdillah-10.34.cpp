//F

#include<iostream>
using namespace std;

int tc;
int n, minVal;
long long int sum = 0;

int main() {
	ios_base::sync_with_stdio(0);
	cin.tie(NULL);

	cin >> tc;
	for(int i = 0; i < tc; i++) {
		minVal = 10000000;
		cin >> n;
		//n = 100000;
		int a[n];
		for(int i = 0; i < n; i++) {
			cin >> a[i];
			//a[i] = 1000000;
			minVal = min(minVal, a[i]);
		}
		sum = -1 * ((long long int)minVal *(long long int)n);
		for(int i = 0; i < n; i++) {
			sum += a[i];
		}
		cout << sum << '\n';
	}
	return 0;
}

#include <stdio.h>
#include <iostream>
using namespace std;
int main()
{
    int tc;
    cin>>tc;
    while (tc--)
    {
        long long int sum=0;
        long long int a;
        long long int mini=-1;
        int n;
        cin>>n;
        for (int i=0;i<n;i++)
        {
            cin>>a;
            if (mini==-1)mini=a;
            if (a<mini)mini=a;
            sum+=a;
        }
        printf ("%lld\n",sum-mini*n);
    }
}

#include <iostream>
#include <algorithm>

#define lo long long

using namespace std;

lo n, tab[100100],mini,t;
int main()
{
	cin>>t;
	while(t--)
	{
		cin>>n;
		mini=1000000009;
		lo ans=0;
		for (int i=0;i<n;i++)
		{
			cin>>tab[i];
			mini=min(mini,tab[i]);
		}
		for (int i=0;i<n;i++)
		{
			ans+=tab[i]-mini;
		}
		
		cout<<ans<<endl;
	}
	
	return 0;
}

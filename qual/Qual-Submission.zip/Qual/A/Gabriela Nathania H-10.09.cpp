#include<stdio.h>

int tc,n,data[1000010],mini;
long long ans;

int main (){
    scanf("%d",&tc);
    while (tc--){
        mini = 1000000000;
        ans =0;
        scanf("%d",&n);
        for(int i = 0; i<n;i++){
            scanf("%d",&data[i]);
            if (mini>data[i]){
                mini = data[i];
            }
        }
        for(int i = 0; i<n;i++){
            if (mini<data[i]){
                ans += data[i]-mini;
            }
        }
        printf("%lld\n",ans);
    }
return 0;
}

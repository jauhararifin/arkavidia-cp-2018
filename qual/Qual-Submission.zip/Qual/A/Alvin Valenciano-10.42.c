#include<stdio.h>
int main()
{
    int n,min,j;
    long long int total;
    scanf("%d",&n);
    int i,a;
    for(i=0;i<n;i++)
    {
        scanf("%d",&a);
        long long int arr[a];
        total = 0;
        for(j=0;j<a;j++)
        {
            scanf("%lld",&arr[j]);
        }
        min = arr[0];
        for(j=1;j<a;j++)
        {
            if(min > arr[j])
            min = arr[j];
        }
        for(j=0;j<a;j++)
        {
            total = total + (arr[j] - min);
        }
        printf("%lld\n",total);


    }
    return 0;
}

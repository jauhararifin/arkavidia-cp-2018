#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;
int main(){
	int t,x,y;
	ll sum=0;
	ll c;
	
	cin>>t;
	
	while(t--){
		cin>>x;
		sum=0;
		ll arr[x];
		ll min = INT_MAX;
		for(int i=0; i<x; i++){
			cin>>arr[i];
			sum+=arr[i];
			if(arr[i]<min)
				min = arr[i];
		}
		c = min*x;
		cout<<sum-c<<endl;
	}
	
	return 0;
}


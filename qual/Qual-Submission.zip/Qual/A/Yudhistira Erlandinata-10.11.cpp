#include <bits/stdc++.h>

using namespace std;

int main(){
    int t;
    cin >> t;
    long n, sum, a, minim;
    for(int i = 0; i < t; i++){
        cin >> n;
        sum = 0;
        minim = 10000000;
        for(int j = 0; j < n; j++){
            cin >> a;
            sum += a;
            minim = min(a, minim);
        }
        cout << sum - (n * minim) << endl;
    }
    return 0;
}

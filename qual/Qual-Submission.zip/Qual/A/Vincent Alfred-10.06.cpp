#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
ll n, a[100005];

int main() {
	int tc;
	scanf("%d", &tc);
	while (tc--) {
		scanf("%lld", &n);
		ll sum = 0, mini = (ll)1e9;
		for (ll i = 0; i < n; i++) {
			scanf("%lld", &a[i]);	
			if (a[i] < mini) mini = a[i];
			sum += a[i];
		}
		printf("%lld\n", sum-(mini*n));
	}
	return 0;	
}

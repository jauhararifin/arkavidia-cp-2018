#include<stdio.h>

long long int Min(long long int N,long long int A[]){
	int i;
	long long int min = A[0];
	
	for(i = 0; i < N; i++){
		if(A[i] < min){
			min = A[i];
		}
	}
	
	return min;
}

int main(){
	int T;
	int i,j;
	
	do{
		scanf("%d", &T);
	}while(T<1||T>1000);
	
	long long int N[T];
	long long int sum[T] ;
	long long int min[T] ;
	
	
	for( i = 0; i < T; i++){
		do{			
			scanf("%lld", &N[i]);
		}while(N[i]<1||N[i]>100000);
			
	
	sum[i] = 0;		
	long long int A[N[i]];
	
		for(j = 0; j < N[i]; j++){
			do{			
				scanf("%lld", &A[j]);
			}while(A[j]<1||A[j]>1000000);
				
			sum[i] += A[j];
		}
			
	min[i] = Min(N[i], A);
	
		}
		
	for(i = 0; i<T; i++){
		printf("%lld\n", sum[i] - min[i]*N[i]);
		
	}
	
	return 0;
}

#include<bits/stdc++.h>
#define cincout ios::sync_with_stdio(false)
#define mp make_pair
#define fi first
#define se second
#define pb push_back

using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef map<int, int> mii;

int t;
ll n;
ll a[100005];
ll mins,cnt;
int main(){
	cin >> t;
	for(int i=1;i<=t;i++){
		cin >> n;
		mins = 1000005;
		cnt=0;
		for(int j=1;j<=n;j++){
			cin >> a[j];
			if(a[j]<mins) mins=a[j];
		}
		for(int j=1;j<=n;j++){
			cnt+=(a[j]-mins);
		}
		cout << cnt <<endl;
	}
}

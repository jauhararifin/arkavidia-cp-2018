#include<bits/stdc++.h>
using namespace std;
#define LL long long
#define ULL unsigned LL
#define PII pair<int,int>
#define VI vector<int>
#define VPII vector< PII >
#define VVI vector< VI >
#define PB push_back
#define F first
#define S second
const int INF=1e9;
const int MOD=1e9+7;
int t,n,a[100000];
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        int mini=INF;
        for(int i=0;i<n;i++)scanf("%d",&a[i]),mini=min(mini,a[i]);
        LL ans=0;
        for(int i=0;i<n;i++){
            a[i]=a[i]-mini;
            ans=ans+a[i];
        }
        printf("%lld\n",ans);
    }
    return 0;
}

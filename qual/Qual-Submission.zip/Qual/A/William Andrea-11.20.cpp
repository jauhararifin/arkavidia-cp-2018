#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
#define pb push_back
#define mp make_pair
#define pii pair<int, int>
#define ff first
#define ss second
#define nl '\n'
#define sp ' '
#define cnl cout<<nl
#define nrep(i,a,b,c) for (int i=a; i<=b; i++)
#define rep(i,a,b) for (int i=a; i<=b; i++)
#define repp(i,a,b) for (int i=a; i>=b; i--)
#define l(s) int len=s.size()


int main(){
    //ios_base::sync_with_stdio(0); cin.tie(0);
    int tc;
    cin>>tc;
    while (tc--){
        ll n, x[100005]={}, mn;
        ll sum=0;
        cin>>n;
        rep (i, 0, n-1){
            cin>>x[i];
            if (i==0) mn=x[i];
            else mn=min(mn, x[i]);
            sum+=x[i];
        }
        cout<<sum-mn*n<<"\n";
    }
    return 0;
}

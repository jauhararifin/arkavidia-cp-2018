#include <iostream>
using namespace std;

int main()
{
    long long int T,N,A, kecil, jumlah, hasil[150];

    cin >> T;

    for (int a=1; a<=T; a++)
    {
        cin >> N;
        jumlah=0;
        kecil=1000000000;
        for (int b=1; b<=N; b++)
        {
            cin >> A;
            jumlah+=A;
            if (A<kecil)
            {
                swap(A,kecil);
            }
        }
        hasil[a]=jumlah-(kecil*N);
    }

    for (int a=1; a<=T; a++)
    {
        cout << hasil[a]<<endl;
    }
    return 0;
}

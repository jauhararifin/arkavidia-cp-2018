#include <bits/stdc++.h>
#define mod 1000000007
using namespace std;
long long l,r,t,n,temp,x[200005],f[200005]={0},q1,ans;
bool boo=false;
pair<long long,long long> q[200005];

vector <pair<long long,pair<long long,long long> > > v;

long long upper(long long x){
    long long l=0,r=v.size()-1,mid,res;
    while (l<=r){
        mid = (l+r)/2;
        if (v[mid].second.first>=x){
            res = mid;
            r=mid-1;
        } else l=mid+1;
    }
    return res;
}

long long lower(long long x){
    long long l=0,r=v.size()-1,mid,res;
    while (l<=r){
        mid = (l+r)/2;
        if (v[mid].second.second<=x){
            res = mid;
            l=mid+1;
        } else r=mid-1;
    }
    return res;
}
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>t;
    for (int i=0; i<t; i++){
        cin>>n;
        for (int j=1; j<=n; j++){
            cin>>x[j];
        }
        cin>>q1;
        for (int j=1; j<=q1; j++){
            cin>>q[j].first>>q[j].second;
            f[q[j].first]++;
            f[q[j].second]++;
        }

        temp = 0;
        l=r=0;
        boo = false;
        for (int j=1; j<=n; j++){
            if (f[j]>0){
                if (boo){
                    v.push_back({temp,{l,r}});
                    boo=false;
                }
                v.push_back({x[j],{j,j}});
            } else{
                if (!boo){
                    boo=true;
                    temp = x[j];
                    l=r=j;
                } else{
                    temp&=x[j];
                    r=j;
                }
            }
        }
        if (boo){
            v.push_back({temp,{l,r}});
        }
        for (int j=1; j<=q1; j++){
            l = lower(q[j].first);
            r = upper(q[j].second);
            ans = v[l].first;
            for (int k=l+1; k<=r; k++) ans&=v[k].first;
            cout<<ans<<"\n";
        }   
        v.clear();
    }
}
#include <stdio.h>
#include <string>
#include <string.h>
#include <iostream>
#include <algorithm>
#include <stdlib.h>
#include <queue>
#include <vector>
#include <stack>
#include <limits.h>
#include <map>
using namespace std;
#define mp make_pair
#define fi first
#define se second
#define pb push_back
#define ll long long int
#define ull unsigned long long int
int input[200005];
int tree[700005];
void build(int id, int left, int right){
	if(left == right){
		tree[id] = input[left];
	}
	else{
		build(2*id, left, (left+right)/2);
		build(2*id+1, (left+right)/2+1, right);
		tree[id] = tree[id*2]&tree[id*2+1];
	}
}

int query(int id, int left, int right, int kiri, int kanan){

	// kalau ga berhubungan sama sekali
	// if(left > kanan || right < kiri) return -INF;
	if(left > kanan || right < kiri) return -1;

	// kalau di dalamnya
	if(left >= kiri && right <= kanan)return tree[id];

	// ke kiri
	int q1 = query(id*2, left, (left+right)/2, kiri, kanan);

	// ke kanan
	int q2 = query(id*2+1, (left+right)/2+1, right, kiri, kanan);
    //printf("%d %d %d %d %d %d\n",id,tree[id],left,right,kiri,kanan);
    //printf("!%d %d\n",q1,q2);
    if(q1==-1) return q2;
    else if(q2==-1) return q1;
    else return q1&q2;
	//return max(q1,q2);
}
int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        memset(input,0,sizeof input);
        memset(tree,0,sizeof tree);
        int n,tmp;
        scanf("%d",&n);
        for(int a=0;a<n;a++){
            scanf("%d",&input[a]);
            if(!a) tmp=input[a];
            else tmp&=input[a];//printf("~%d\n",31&(1<<5));
        }

        build(1,0,n-1);
        int q;
        scanf("%d",&q);
        while(q--){
            int l,r;
            scanf("%d %d",&l,&r);
            int ans=query(1,0,n-1,l-1,r-1);
            printf("%d\n",ans);
        }
    }
    return 0;
}

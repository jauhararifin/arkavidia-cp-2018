#include<stdio.h>

int tc,n,a,b,q,data[200010][32], sum[200020][32],banyak,ans,x,pow[32];

int main (){
    scanf("%lld",&tc);
    pow[0] = 1;
    for (int i = 1; i<32;i++){
        pow[i] = pow[i-1]*2;
    }
    while (tc--){
        scanf("%d",&n);
        for (int i = 1; i<=n;i++){
            scanf("%d",&x);
            for (int bit = 0; bit<32;bit++){
                if (x&1) data[i][bit] = 1;
                else data[i][bit] = 0;
                x>>=1;
            }
        }

        for (int i = 0; i<32; i++){
            for (int j = 1; j<=n; j++){
                sum[j][i] = sum[j==0?0:j-1][i]+data[j][i];
            }
        }
        scanf("%d",&q);
        while (q--){
            ans = 0;
            scanf("%d%d",&a,&b);
            banyak = b-a+1;
            a--;
            for (int i=0; i<32;i++){
                if (sum[b][i]-sum[a][i]==banyak){
                    ans += pow[i];
                }
            }
            printf("%d\n",ans);
        }


    }
return 0;
}

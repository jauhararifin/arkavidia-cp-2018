#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define MOD 1000000007
#define fi first
#define se second

ll modexp(ll a, ll b, ll m){
    ll res = 1;
    for(; b; b >>= 1, a = (a*a)%m)
        if(b&1) res = (res*a)%m;
    return res%m;
}

int main(){
	int t, n, q, l, r;
	ll a, b;
	scanf("%d", &t);
	while(t--){
		scanf("%d", &n);
		ll x;
		ll cnt[100][n];

		for(int i = 0; i < 100; i++){
			for(int j = 0; j < n; j++) cnt[i][j] = 0;
		}

		for(int i = 0; i < n; i++){
			scanf("%lld", &x);
			int hit = 0;
			while(x > 0){
				if(x%2 == 1){
					if(i == 0) cnt[hit][i] = 1;
					else cnt[hit][i] = cnt[hit][i-1]+1;
				}
				
				hit++;
				x/=2;
			}
		}

		scanf("%d", &q);

		for(int i = 0; i < q; i++){
			scanf("%d%d", &l, &r);
			l--; r--;
			ll ans = 0;
			ll tmp = 1;
			for(int j = 0; j < 100; j++){
				if(l == 0){
					if(r-l+1 == cnt[j][r]) ans+=tmp; 
				}
				else{
					if(r-l+1 == cnt[j][r] - cnt[j][l-1]) ans+=tmp;
				}
				tmp*=2;
			}
			printf("%lld\n", ans);
		}
	}
	return 0;
}

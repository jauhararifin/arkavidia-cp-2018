#include<bits/stdc++.h>
using namespace std;

int main(){
    int t;
    scanf("%d",&t);
    // printf("%d\n",t);
    while(t--){
        int n;scanf("%d",&n);
        // printf("%d\n",n);
        int arr[n+1];
        // printf("hehe %d\n",n);
        int bit[n+1][31];
        // printf("hehe %d\n",n);
        memset(bit,0,sizeof(bit));
        // printf("hehe %d\n",n);
        for(int i=0;i<n;i++){
            scanf("%d",&arr[i]);
            // printf("!!%d\n",arr[i]);
            for(int j=0;j<=30;j++){
                // printf("%d\n",j);
                if(arr[i] & (1<<j)){
                    //printf("%d %d %d\n",arr[i],(1<<j),j);
                    bit[i+1][j]+=1;
                    //if(j<10) printf("!!!!!!!! %d %d\n",bit[j].first,bit[j].second);
                }
                // else{
                //     bit[j].first = 0;
                //     bit[j].second = 0;
                // }

            }
            //printf("%d\n",arr[i]);
        }
        for(int i=2;i<=n;i++){
            for(int j=0;j<=30;j++){
                bit[i][j]+=bit[i-1][j];
                //printf("%d ",bit[i][j]);
            }
            //printf("\n");
        }
        int q;scanf("%d",&q);
        while(q--){
            int l,r;
            scanf("%d %d",&l,&r);
            int ans=0;
            bool ketemu=false;
            for(int i=0;i<=30;i++){
                //printf("%d %d %d %d\n",bit[l-1][i],bit[r-2][i],l,r-1);
                if(bit[r][i]-bit[l-1][i] == r-l+1){
                    
                    ans+=(1<<i);
                    ketemu=true;
                }
            }
            printf("%d\n",ans);
        }
    }
    return 0;
}
#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

typedef vector<int> vi;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef vector<pii> vii;

#define mp make_pair
#define fi first
#define se second

#define pb push_back
#define pob pop_back
#define pf push_front
#define pof pop_front

#define FOR(i,n) for(int i=0;i<n;i++)
#define REPP(i,l,r,c) for(int i=l;i<=r;i+=c)
#define REP(i,l,r) REPP(i,l,r,1)

#define FORD(i,n) for(int i=n-1;i>=0;i--)
#define REVV(i,l,r,c) for(int i=max(l,r),_m=min(l,r);i>=_m;i-=c)
#define REV(i,l,r) REVV(i,l,r,1)

int tr[8000010];
int a[2000010];
void build (int p, int l, int r) {
	if (l == r) { tr[p] = a[l];return;}
	int mid = (l+r)/2;
	build(p*2, l, mid);
	build (p*2+1, mid+1, r);
	tr[p] = tr[p*2]&tr[p*2+1];
}

int query(int p, int l, int r, int i, int j) {
	if (l > j || r <i) return -1;
	if (l >= i&& r <= j) return tr[p];
	int mid = (l+r)/2;
	return query(p*2, l, mid, i, j)&query(p*2+1, mid+1, r, i, j);
}

int main(){
	int tc; cin>>tc;
	while(tc--){
		int n; cin>>n;
		REP(i,1,n) cin>>a[i];
		build(1, 1, n);
		int l, r, q;
		cin>>q;
		while(q--){
			cin>>l>>r;
			cout<<query(1, 1, n, l, r)<<endl;
		}
	}
	return 0;
}

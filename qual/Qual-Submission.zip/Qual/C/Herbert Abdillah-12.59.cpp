//C
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iostream>
using namespace std;

unsigned int tc, i, arrSz, q, l, r, k;
int getMid(int s, int e) {
	return s + (e -s)/2;
}

int getAndUtil(int *st, int ss, int se, int qs, int qe, int si)
{
    if (qs <= ss && qe >= se)
        return st[si];
    if (se < qs || ss > qe)
    	return 2147483647;
    int mid = getMid(ss, se);
    int ret1 = getAndUtil(st, ss, mid, qs, qe, 2*si+1);
    int ret2 =  getAndUtil(st, mid+1, se, qs, qe, 2*si+2);
    int retVal = ret1 & ret2;
    return retVal;
}

int getAnd(int *st, int n, int qs, int qe)
{
    int retVal = getAndUtil(st, 0, n-1, qs, qe, 0);
    return retVal;
}

int constructSTUtil(int arr[], int ss, int se, int *st, int si)
{
    if (ss == se)
    {
        st[si] = arr[ss];
        return arr[ss];
    }
    int mid = getMid(ss, se);
    st[si] =  constructSTUtil(arr, ss, mid, st, si*2+1) &
              constructSTUtil(arr, mid+1, se, st, si*2+2);
    return st[si];
}

int *constructST(int arr[], int n)
{
    int x = (int)(ceil(log2(n)));
    int max_size = 2*(int)pow(2, x) - 1;
    int *st =  (int *)malloc(sizeof(int)*max_size);
    constructSTUtil(arr, 0, n-1, st, 0);

    return st;
}

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(NULL);
	cin >> tc;
	for(i = 0; i < tc; i++) {
		cin >> arrSz;
		int arr[arrSz];
		for(k = 0; k < arrSz; k++) {
			cin >> arr[k];
		}
		int *st = constructST(arr, arrSz);
		cin >> q;
		for(k = 0; k < q; k++) {
			//query
			cin >> l >>r;
			cout << getAnd(st, arrSz, l-1, r-1) << '\n';
		}
	}

    return 0;
}


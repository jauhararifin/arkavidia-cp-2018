#include <bits/stdc++.h>

#define fi first
#define se second
#define sz(a) (int)(a).size()
#define all(a) (a).begin(), (a).end()
#define reset(a, v) memset((a), v, sizeof (a))

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef vector<ii> vii;

const int N = 200005;

int n, q;
int dat[35][N];
int ps[35][N];

int main() {
	int tc; scanf("%d", &tc);
	while (tc--) {
		scanf("%d", &n);
		for (int i = 1; i <= n; ++i) {
			int x; scanf("%d", &x);
			for (int j = 0; j < 30; ++j) {
				if (x & (1 << j)) {
					dat[j][i] = 1;
				}
				ps[j][i] = dat[j][i] + ps[j][i-1];
			}
		}

		scanf("%d", &q);
		while (q--) {
			int l, r; scanf("%d %d", &l, &r);
			int ans = 0;
			for (int i = 0; i < 30; ++i) {
				int res = ps[i][r] - ps[i][l-1];
				if (res == r-l+1) ans ^= (1 << i);
			}
			printf("%d\n", ans);
		}
		reset(dat, 0);
		reset(ps, 0);
	}
	return 0;
}
#include <bits/stdc++.h>
using namespace std;

int n, q;
int st[800000], arr[200009];

void build(int id, int l, int r) {
    if (l == r) {
        st[id] = arr[l];
        return;
    }
    int m = (l + r) / 2;
    build(id*2, l, m);
    build(id*2 + 1, m + 1, r);
    st[id] = st[id*2] & st[id*2+1];
}

int query(int id, int i, int j, int l, int r) {
    if (i > j || i > r || j < l) {
        return -1;
    }
    if (l <= i && j <= r) {
        return st[id];
    }
    int m = (i + j) / 2;
    int kiri = query(id*2, i, m, l, r);
    int kanan = query(id*2+1, m+1, j, l, r);
    return kiri & kanan;
}

int main() {
    int TC;
    scanf("%d", &TC);
    while (TC--) {
        scanf("%d", &n);
        for (int i = 1; i <= n; i++) {
            scanf("%d", &arr[i]);
        }
        build(1, 1, n);

        scanf("%d", &q);
        while (q--) {
            int l, r;
            scanf("%d %d", &l, &r);
            printf("%d\n", query(1, 1, n, l, r));
        }
    }
}
#include<stdio.h>
#include<string.h>

#include<iostream>
#include<string>
#include<algorithm>
#include<map>

using namespace std;

int angka[200500];
int tree[1000000];
int dan[200500];

int build(int left, int right, int node)
{
	if(left==right)
	{
		tree[node]=angka[left];
		return tree[node];
	}
	int mid = (left+right)/2;
	int darikiri = build(left,mid,node*2);
	int darikanan = build(mid+1,right,(node*2)+1);
	tree[node] = darikiri&darikanan;
	return tree[node];
}

int cari(int left, int right, int node, int tanyal, int tanyar)
{
	
	if(right<tanyal || left>tanyar)
	{
		return 1073741824-1;
	}
	else if(left>=tanyal && right<=tanyar)
	{
		//cout<<tree[node]<<endl;
		return tree[node];
	}
	else
	{
		int mid = (left+right)/2;
		int carikiri = cari(left,mid,node*2,tanyal,tanyar);
		int carikanan = cari(mid+1,right,(node*2)+1,tanyal,tanyar);
		//cout<<carikiri<<" "<<carikanan<<endl;
		return (carikiri&carikanan);
	}
}

int main()
{
	
	int t,n,m,l,r;
	
	cin>>t;
	while(t--)
	{
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&angka[i]);
		}
		build(1,n,1);
		
		cin>>m;
		for(int i=0;i<m;i++)
		{
			cin>>l>>r;
			int print = cari(1,n,1,l,r);
			cout<<print<<endl;
		}
	}
	return 0;
}

#include <bits/stdc++.h>

#define FAST_IO ios_base::sync_with_stdio(0); \
				cin.tie(0); \
				cout.tie(0)
#define pb push_back
#define fi first
#define se second
#define mp make_pair
#define all(_v)             _v.begin(), _v.end()
#define sz(_v)              (int) _v.size()
#define FIND(_obj, _val)    (_obj.find(_val) != _obj.end())
#define RESET(_a, _v)       fill_n(_a,sizeof(_a)/sizeof(_a[0]),_v)
#define REP(_i, _n)         for (int _i = 0; _i < (int) _n; _i++)
#define FOR(_i, _a, _b)     for (int _i = (int) _a; _i <= (int) _b; _i++)
#define FORD(_i, _a, _b)    for (int _i = (int) _a; _i >= (int) _b; _i--)
#define FORIT(_it, _obj)    for (auto _it = _obj.begin(); _it != _obj.end(); _it++)

// DEBUG UTIL
#define DEBUG(x) cerr << "> " << #x << " = " << x << endl

using namespace std;

using ll = long long;
using ull = unsigned long long;
using ld = long double;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pdd = pair<double,double>;
using vi = vector<int>;
using vii = vector<pii>;
using vs = vector<string>;

const int DR[] = {-1, 0, 1, 0};
const int DC[] = {0, -1, 0, 1};
const double PI = acos(-1.0);
const double EPS = 1e-9;
const int MOD = 1e9 + 7;
const int INF = 1073741823;
const ll INFLL = 4e18;
const int MAX = 2e5;

struct Node {
	ll val;

	Node() {
		val = 0;
	}
};

Node stree[4*MAX+5];

void update(int id, int l, int r, int x, int y, ll val) {
	if (x<=l && r<=y) {
		stree[id].val = val;
	}
	else {
		int chld = id<<1;
		int m = (l+r)/2;

		if (x<=m) update(chld, l, m, x, y, val);
		if (y>m) update(chld+1, m+1, r, x, y, val);

		stree[id].val = stree[chld].val & stree[chld+1].val;
	}
}

ll query(int id, int l, int r, int x, int y) {
	if (x<=l && r<=y) {
		return stree[id].val;
	}
	else {
		int chld = id<<1;
		int m = (l+r)/2;
		ll ret = -1;

		if (x<=m) ret = query(chld, l, m, x, y);
		if (y>m) {
			if (ret == -1) ret = query(chld+1, m+1, r, x, y);
			else ret &= query(chld+1, m+1, r, x, y);
		}

		return ret;
	}
}

int N, Q;
ll arr[MAX+5];

void read() {
	cin >> N;
	FOR(i,1,N) cin >> arr[i];
	cin >> Q;
}

// interface
void update(int x, int y, ll val) {
	update(1, 1, N, x, y, val);
}

ll query(int x, int y) {
	return query(1, 1, N, x, y);
}

void init() {
	FOR(i,0,4*MAX+3)
		stree[i].val = 0;

	FOR(i,1,N)
		update(i, i, arr[i]);
}

void solve() {
	REP(q,Q) {
		int l, r;
		cin >> l >> r;

		cout << query(l, r) << "\n";
	}
}

int main() {
	FAST_IO;
	int TC = 1; cin >> TC;
	while (TC--) {
		read();
		init();
		solve();
	}
}
#include <bits/stdc++.h>
using namespace std;

#define FAST_CC ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define fi first
#define se second
#define pb push_back
#define RESET(s, x) memset(s, x, sizeof(s))

typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int, vii > viii;

const double PI = acos(-1.0);
const double EPS = 1e-9;
const int MOD = 1e9 + 7;
const int INF = 1e9;
const long long INFLL = 4e18;
const int dr[] = {-1, 0, 1, 0, -1, 1, 1, -1};
const int dc[] = {0, 1, 0, -1, 1, 1, -1, -1};

const int NMAX = 2e5;
int arr[NMAX + 5], stree[4 * NMAX + 5];

//SEGMENT TREE MAX QUERY
void build(int l, int r, int pos) {
	if (l == r) {
		stree[pos] = arr[l];
	} else {
		int mid = (l + r) / 2;
		build(l, mid, 2 * pos + 1);
		build(mid + 1, r, 2 * pos + 2);
		stree[pos] = (stree[2 * pos + 1] & stree[2 * pos + 2]);
	}
}

int query(int l, int r, int ql, int qr, int pos) {
	if (ql <= l && r <= qr) {
		return stree[pos];
	} else if (qr < l || r < ql) {
		return 2147483647;
	} else {
		int mid = (l + r) / 2;
		return (query(l, mid, ql, qr, 2 * pos + 1) & query(mid + 1, r, ql, qr, 2 * pos + 2));
	}
}
int main() {
	int t;
	scanf("%d", &t);
	while(t--) {
		int n;
		scanf("%d", &n);
		for (int i = 0; i <= 4 * NMAX; i++) {
			stree[i] = 0;
		}
		
		for (int i = 0; i < n; i++) {
			scanf("%d", &arr[i]);
		}

		build(0, n - 1, 0);

		int q;
		scanf("%d", &q);

		for (int i=0; i<q; i++) {
			int l, r;
			scanf("%d %d", &l, &r);
			l--, r--;
			printf("%d\n", query(0, n - 1, l, r, 0));
		}
	}
	return 0;
}
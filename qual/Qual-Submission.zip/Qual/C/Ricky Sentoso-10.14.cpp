#include<bits/stdc++.h>
using namespace std;
#define LL long long
#define ULL unsigned LL
#define PII pair<int,int>
#define VI vector<int>
#define VPII vector< PII >
#define VVI vector< VI >
#define PB push_back
#define F first
#define S second
const int INF=1e9;
const int MOD=1e9+7;
int t,n,q,a[200000],tree[200000*4];
void build(int id,int l,int r){
    if(l==r){
        tree[id]=a[l];
        return;
    }
    int m=(l+r)/2;
    build(id<<1,l,m);
    build((id<<1)+1,m+1,r);
    tree[id]=tree[id<<1]&tree[(id<<1)+1];
}
int query(int id,int l,int r,int i,int j){
    if(l>j||r<i)return -1;
    if(l>=i&&r<=j)return tree[id];
    int m=(l+r)/2;
    int le=query(id<<1,l,m,i,j);
    int ri=query((id<<1)+1,m+1,r,i,j);
    if(le==-1)return ri;
    if(ri==-1)return le;
    return le&ri;
}
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        for(int i=0;i<n;i++)scanf("%d",&a[i]);
        build(1,0,n-1);
        scanf("%d",&q);
        while(q--){
            int l,r;
            scanf("%d %d",&l,&r);
            l--;
            r--;
            printf("%d\n",query(1,0,n-1,l,r));
        }
    }
    return 0;
}

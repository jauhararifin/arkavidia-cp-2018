#include <bits/stdc++.h>

using namespace std;
int n, seg[2000200],tab[200100],q,l,r,t;
int build_seg(int ind, int l, int r)
{
	if (r-l==1)
	{
		seg[ind]=tab[l];
		return seg[ind];
	}
	
	int mid=l+(r-l)/2;
	
	int sim1=build_seg(2*ind, l, mid);
	int sim2=build_seg(2*ind + 1, mid, r);
	seg[ind]=sim1&sim2;
	
	return seg[ind];
}
int ans(int ind, int L, int R, int l, int r)
{
	if (r<=L) return INT_MAX;
	if (R<=l) return INT_MAX;
	if (l<=L && R<=r) return seg[ind];
	
	int mid=L+(R-L)/2;
	
	int sim1=ans(2*ind, L, mid, l, r);
	int sim2=ans(2*ind + 1, mid, R, l, r);
	
	return sim1&sim2;
}
int main()
{
	cin>>t;
	while(t--)
	{
		cin>>n;
		for (int i=0;i<n;i++) cin>>tab[i];
		
		memset(seg,0,sizeof(seg));
		
		build_seg(1,0,n);
		
		cin>>q;
		
		while(q--)
		{
			cin>>l>>r;
			l--;
			cout<<ans(1,0,n,l,r)<<endl;	
		}
	}
	return 0;
}

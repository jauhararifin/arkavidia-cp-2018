#include<bits/stdc++.h>
using namespace std;

const int sisa=(1<<30)-1;

int tc;
int n,q;
int li[200005];
int st[600005];

void build(int node, int l, int r)
{
	if(l==r)
	{
		st[node]=li[l];
		return;
	}
	build(node*2,l,(l+r)/2);
	build(node*2+1,(l+r)/2 +1,r);
	st[node]=st[node*2]&st[node*2+1];
	return;
}

int que(int node, int l, int r, int a, int b)
{
	if(l>b) return sisa;
	if(r<a) return sisa;
	if(l>=a && r<=b) return st[node];
	return que(node*2,l,(l+r)/2,a,b)&que(node*2+1,(l+r)/2 +1,r,a,b);
}

int l,r;
int main()
{
	scanf("%d",&tc);
	while(tc--)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&li[i]);
		}
		build(1,1,n);
		scanf("%d",&q);
		for(int i=1;i<=q;i++)
		{
			scanf("%d%d",&l,&r);
			int ans=que(1,1,n,l,r);
			printf("%d\n",ans);
		}
	}
 	return 0;
}


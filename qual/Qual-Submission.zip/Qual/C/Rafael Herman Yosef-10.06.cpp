#include<stdio.h>
#include<sstream>
#include<iostream>

#include<math.h>
#include<algorithm>
#include<utility>
#include<string.h>
#include<string>
#include<stdlib.h>
#include<assert.h>
#include<time.h>

#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>

#define FI first
#define SE second
#define PB push_back
#define MP make_pair
#define endl '\n'
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

void desperate_optimization(int precision){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(precision);
}

int n;

ll ST[4 * 200005];
ll arr[200005];

void build(int idx,int l,int r){
	if(l == r){
		ST[idx] = arr[l];
		return ;
	}
	int mid = (l + r)/2;
	build(2*idx,l,mid),build(2*idx + 1,mid +1,r);
	ST[idx] = (ST[2*idx] & ST[2*idx + 1]);
}

ll query(int idx,int l,int r,int le,int ri){
	if(r < le || ri < l) return 8589934591LL;
	if(le <= l && r <= ri) return ST[idx];
	int mid = (l + r)/2;
	return (query(2*idx,l,mid,le,ri) & query(2*idx + 1,mid+1,r,le,ri));
}

int main(){
	desperate_optimization(10);
	int ntc;
	cin>>ntc;
	while(ntc--){
		cin>>n;
		for(int i=1;i<=n;i++) cin>>arr[i];
		build(1,1,n);
		int q;
		cin>>q;
		while(q--){
			int l,r;
			cin>>l>>r;
			cout<<query(1,1,n,l,r)<<endl;
		}
	}
	return 0;
}


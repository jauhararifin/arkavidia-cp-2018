#include<stdio.h>
#include<string.h>
long long int dp[600003];
long long int arr[200001];
long long int xori(int index,int from,int to){
    if(from==to) return dp[index]=arr[from];
    int mid=(from+to)/2;
    return dp[index]=xori(index*2,from,mid)&xori(index*2+1,mid+1,to);
}

long long int search(int index,int from,int to,int nfrom,int nto){
    if(nfrom==from&&nto==to) return dp[index];
    int mid=(nfrom+nto)/2;
    if(from>mid) return search(index*2+1,from,to,mid+1,nto);
    if(to<=mid) return search(index*2,from,to,nfrom,mid);
    return search(index*2+1,mid+1,to,mid+1,nto)&search(index*2,from,mid,nfrom,mid);
}

int main(){
    int tc,n;
    scanf("%d",&tc);
    while(tc--){
        scanf("%d",&n);
        for(int i=0;i<n;i++) scanf("%lld",&arr[i]);
        xori(1,0,n-1);
        int q;
        scanf("%d",&q);
        int a,b;
        while(q--){
            scanf("%d%d",&a,&b);
            printf("%lld\n",search(1,a-1,b-1,0,n-1));
        }
    }
    return 0;
}
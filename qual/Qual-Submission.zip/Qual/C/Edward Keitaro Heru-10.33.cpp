#include<bits/stdc++.h>

using namespace std;
typedef long long ll;
#define mp make_pair
#define pb push_back
#define pob pop_back
#define fi first
#define se second

const int N=200005;
const ll xx=pow(2,31)-1;

ll dat[N];
ll tree[4*N];

void build(int idx, int l, int r){
	if(l==r){
		tree[idx]=dat[l];
		return;
	}
	int mid=(l+r)/2;
	build(idx*2,l,mid);
	build(idx*2+1,mid+1,r);
	tree[idx]=tree[idx*2]&tree[idx*2+1];
//	printf("%d %lld %lld %lld\n",idx, left, right, tree[idx]);
//	tree[idx]=(build(idx*2,l,mid)&build(idx*2+1,mid+1,r));
}

ll query(int idx, int l, int r, int a, int b){
	if(l>=a && r<=b){
		return tree[idx];
	}
	if(l>b || r<a) return xx;
	int mid=(l+r)/2;
	return (query(idx*2,l,mid,a,b)&query(idx*2+1,mid+1,r,a,b));
}

int main(){
	int t;
	cin>>t;
	while(t--){
		int n;
		cin>>n;
		for(int i=1; i<=n; i++){
			cin>>dat[i];
		}
//		memset(tree,0,sizeof(tree));
		build(1,1,n);
		int q;
		cin>>q;
		int l,r;
		while(q--){
			cin>>l>>r;
			cout<<query(1,1,n,l,r)<<endl;
		}
	}
	return 0;
}

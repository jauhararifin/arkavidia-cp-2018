#include<bits/stdc++.h>
using namespace std;

#define ll long long
#define maxn 200000

int ar[maxn + 1][31];

int main() {
	int tes, n, A, q, has, L, R, range;
	scanf("%d", &tes);
	while(tes--) {
		scanf("%d", &n);
		for(int i = 1; i <= n; i++) {
			scanf("%d", &A);
			for(int j = 0; j < 31; j++) {
				ar[i][j] = ((A & (1 << j)) != 0);
			}
		}
		for(int i = 1; i <= n; i++) {
			for(int j = 0; j < 31; j++) {
				ar[i][j] += ar[i - 1][j];
			}
		}
		scanf("%d", &q);
		while(q--) {
			scanf("%d %d", &L, &R);
			range = R - L + 1;
			has = 0;
			for(int j = 0; j < 31; j++) {
				has |= ((range == ar[R][j] - ar[L - 1][j]) << j);
			}
			printf("%d\n", has);
		}
	}
}
#include<stdio.h>

#define DEF_VAL -1
#define TREE_BIT 18

struct STree{
    int idMin, idMax; 
    int val;
};

STree tree[1 << (TREE_BIT+1)];
int refb[1 << TREE_BIT];  
long long int a[1 << TREE_BIT];  

long long int Aggregate(int val1, int val2){
    return val1 & val2;
}

void BuildTree(int id, int idMin, int idMax){ 
    tree[id].idMin = idMin;
    tree[id].idMax = idMax;

    if(idMin == idMax){ //udah sampe leaf node
        tree[id].val = a[idMin];
        refb[idMin] = id;
    }
    else{
        int idMid = (idMin + idMax) / 2;
        BuildTree(id*2, idMin, idMid);  //anak kiri
        BuildTree(id*2+1, idMid+1, idMax); //anak kanan
        tree[id].val = Aggregate(tree[id*2].val, tree[id*2+1].val);
    }

}

long long int Query(int id, int idMin, int idMax){
    if(idMax < tree[id].idMin) {
    	return DEF_VAL;	
	}
    if(idMin > tree[id].idMax) {

		return DEF_VAL;
	}
    if(idMin <= tree[id].idMin && idMax >= tree[id].idMax) return tree[id].val;

    long long int resL = Query(id*2, idMin, idMax);
    long long int resR = Query(id*2+1, idMin, idMax);
    return Aggregate(resL, resR); // ngereturn nilai dari resL & resR
}

int main(){
	int t, n, q, l, r, i, j, k;
	long long int hasil;
	int duaPangkat;
	
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%d",&n);
		for(j = 0; j<(1 << TREE_BIT); j++)
        	a[j] = 1;
		//memset(a,1,(1<<TREE_BIT));
		for(j = 0;j<n;j++){
			scanf("%lld",&a[j]);
		}
		duaPangkat = 1;
		while(duaPangkat < n){   //nyari jumlah leaves yg dibutuhkan, N itu jumlah inputan array nya
	        duaPangkat = 2*duaPangkat;
	    }
	    BuildTree(1, 0, duaPangkat-1);
//	    for(j=1;j<2*duaPangkat;j++){
//	    	printf("%d ",tree[j].val);
//		}
		scanf("%d",&q);
		for(j=0;j<q;j++){
			scanf("%d %d",&l,&r);
			hasil = Query(1,l-1,r-1);
		//	hasil = a[l-1] & a[r-1];
		
//			hasil = a[l-1];
//			for(k=l;k<r;k++){
//				hasil &= a[k];
//			//	printf("%lld ",hasil);
//			}
			printf("%lld\n",hasil);
		}
	}
	return 0;
}

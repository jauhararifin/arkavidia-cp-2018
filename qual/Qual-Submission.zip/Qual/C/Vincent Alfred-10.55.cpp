#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N = 200005;
int n, q;
ll a[N], st[N*4];

void build (int p, int l, int r) {
	if (l == r) {
		st[p] = a[l];
		return;
	}
	int mid = (l+r)/2;
	build(p*2, l, mid);
	build (p*2+1, mid+1, r);
	st[p] = st[p*2] & st[p*2+1];
}

ll query(int p, int l, int r, int i, int j) {
	if (l > j || r < i) return (ll)((1<<31)-1);
	if (l >= i && r <= j) return st[p];
	int mid = (l+r)/2;
	return query(p*2, l, mid, i, j) & query(p*2+1, mid+1, r, i, j);
}

int main() {
	int tc;
	scanf("%d", &tc);	
	while (tc--) {
		scanf("%d", &n);	
		for (int i = 1; i <= n; i++) scanf("%lld", &a[i]);
		build(1, 1, n);
		scanf("%d", &q);
		while (q--) {
			int l, r;
			scanf("%d %d", &l, &r);	
			if (l > r) {
				int tmp = l;
				l = r;
				r = tmp;
			}
			ll ans = query(1, 1, n, l, r);
			printf("%lld\n", ans);
		}
	}
	return 0;	
}

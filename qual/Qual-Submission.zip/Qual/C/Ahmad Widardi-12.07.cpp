#include<bits/stdc++.h>
#define cincout ios::sync_with_stdio(false)
#define mp make_pair
#define fi first
#define se second
#define pb push_back

using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef map<int, int> mii;
ll t,n,q,x,y;

ll pangkat(ll x){
	if(x==1) return 2;
	if(x%2==0){
		ll tmp = pangkat(x/2);
		return tmp*tmp;
	}else{
		ll tmp = pangkat(x/2);
		return tmp*tmp*2;
	}
}

ll pangkathasil = pangkat(log2(1000000000)+1)-1;

// A utility function to get the middle index from corner indexes.
ll getMid(ll s, ll e) { return s + (e -s)/2; }

/* A recursive function to get the sum of values in given range
	of the array. The following are parameters for this function.

	st --> Pointer to segment tree
	si --> Index of current node in the segment tree. Initially
			0 is passed as root is always at index 0
	ss & se --> Starting and ending indexes of the segment represented
				by current node, i.e., st[si]
	qs & qe --> Starting and ending indexes of query range */
ll getSumUtil(ll *st, ll ss, ll se, ll qs, ll qe, ll si)
{
	// If segment of this node is a part of given range, then return
	// the sum of the segment
	if (qs <= ss && qe >= se)
		return st[si];

	// If segment of this node is outside the given range
	if (se < qs || ss > qe)
		return pangkathasil;

	// If a part of this segment overlaps with the given range
	ll mid = getMid(ss, se);
	return getSumUtil(st, ss, mid, qs, qe, 2*si+1) &
		getSumUtil(st, mid+1, se, qs, qe, 2*si+2);
}

// Return sum of elements in range from index qs (quey start)
// to qe (query end). It mainly uses getSumUtil()
ll getSum(ll *st, ll n, ll qs, ll qe)
{
	return getSumUtil(st, 0, n-1, qs, qe, 0);
}

// A recursive function that constructs Segment Tree for array[ss..se].
// si is index of current node in segment tree st
ll constructSTUtil(ll arr[], ll ss, ll se, ll *st, ll si)
{
	// If there is one element in array, store it in current node of
	// segment tree and return
	if (ss == se)
	{
		st[si] = arr[ss];
		return arr[ss];
	}

	// If there are more than one elements, then recur for left and
	// right subtrees and store the sum of values in this node
	ll mid = getMid(ss, se);
	st[si] = constructSTUtil(arr, ss, mid, st, si*2+1) &
			constructSTUtil(arr, mid+1, se, st, si*2+2);
	return st[si];
}

/* Function to construct segment tree from given array. This function
allocates memory for segment tree and calls constructSTUtil() to
fill the allocated memory */
ll *constructST(ll arr[], ll n)
{
	// Allocate memory for segment tree

	//Height of segment tree
	ll x = (ll)(ceil(log2(n))); 

	//Maximum size of segment tree
	ll max_size = 2*(ll)pow(2, x) - 1; 

	// Allocate memory
	ll *st = new ll[max_size];

	// Fill the allocated memory st
	constructSTUtil(arr, 0, n-1, st, 0);

	// Return the constructed segment tree
	return st;
}

int main(){
	cin >> t;
	for(ll k=1;k<=t;k++){
		cin >> n;
		ll arr[n];
		for(ll i=0;i<n;i++){
			cin >> arr[i];
		}
		ll *st = constructST(arr, n);
		cin >> q;
		for(ll i=0;i<q;i++){
			cin >> x >> y;
			x--;
			y--;
			cout << getSum(st,n,x,y)<<endl;
		}
	}
}

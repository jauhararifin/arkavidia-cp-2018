#include<bits/stdc++.h>
using namespace std;

const int sz = 4*2e5 + 10;
const int INF = 1e9;
const int MOD = 1e9+7;
#define fi first
#define se second
#define ll long long
typedef pair<int,int> ii;
typedef pair<int,ii> iii;
int dX[]={0,0,-1,1};
int dY[]={-1,1,0,0};
int arr[sz]={};
int tree[sz]={};
int x,y,val;

int build(int i,int l, int r){ 
	int mid=(l+r)/2;
	if(l==r) return tree[i]=arr[l];	
	return tree[i]=build(i*2,l,mid)&build(i*2+1,mid+1,r);
}

int query(int i, int l, int r){ 
	int mid=(l+r)/2;
	if(r<x || y<l) return INT_MAX;
	if(x<=l && r<=y) return tree[i];
	return query(i*2,l,mid)&query(i*2+1,mid+1,r);	
}

int main(){
	int tc;
	scanf("%d",&tc);
	while(tc--){
		int n,m;
		scanf("%d",&n);
		for(int i=1;i<=n;i++) scanf("%d",&arr[i]);
		build(1,1,n);
		scanf("%d",&m);
		while(m--){
			scanf("%d %d",&x,&y);
			printf("%d\n",query(1,1,n));
		}
	}
	return 0;
}

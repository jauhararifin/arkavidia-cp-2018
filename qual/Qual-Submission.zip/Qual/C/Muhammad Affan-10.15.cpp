#include <bits/stdc++.h>
using namespace std;

int tree[800010];
int tab[200010];

void reset()
{
	memset(tree,0,sizeof(tree));
	memset(tab,0,sizeof(tab));
}

void build(int node,int l,int r)
{
	if (l==r)
	{
		tree[node]=tab[l];
		return;
	}
	int mid=(l + r) >> 1;
	int idxL=node*2,idxR=node*2+1;
	build(idxL,l,mid);
	build(idxR,mid+1,r);
	tree[node]=tree[idxL]&tree[idxR];
	return;
}

int query(int node,int nodeL,int nodeR,int queryL,int queryR)
{
	if (queryR<nodeL || queryL>nodeR) return -1;
	if (queryL<=nodeL && nodeR<=queryR)
	{
		return tree[node];
	}
	int mid=(nodeL + nodeR) >> 1;
	int idxL=node*2,idxR=node*2+1;
	int kiri=query(idxL,nodeL,mid,queryL,queryR);
	int kanan=query(idxR,mid+1,nodeR,queryL,queryR);
	if (kiri==-1) return kanan;
	if (kanan==-1) return kiri;
	return kiri&kanan;
}

bool IsPrime(int x)
{
	if (x==1) return false;
	int akar=(int)sqrt(x);
	for (int i=2;i<=akar;i++)
	{
		if (x%i==0) return false;
	}
	return true;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
//	freopen("input.txt","r",stdin);
	int t;
	cin>>t;
	while (t--)
	{
		reset();
		int n;
		cin>>n;
		for (int i=0;i<n;i++)
		 cin>>tab[i];
		build(1,0,n-1);
		int q;
		cin>>q;
		for (int i=1;i<=q;i++)
		{
			int a,b;
			cin>>a>>b;
			--a; --b;
			cout<<query(1,0,n-1,a,b)<<"\n";
		}
	}
}

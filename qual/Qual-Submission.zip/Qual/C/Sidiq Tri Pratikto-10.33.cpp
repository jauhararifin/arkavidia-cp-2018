#include<bits/stdc++.h>
#define loop(a,b,c) for(int a=b;a<c;a++)
#define fi first
#define se second
#define mp make_pair
#define all(v) v.begin(),v.end()
#define pb push_back
#define sz(v) v.size()
using namespace std;
typedef long long LL;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef pair<int,ii> iii;
typedef vector<iii> viii;
const double PI=2*acos(0);
const LL MOD=1000*1000*1000+7;
//templates ends here
int a[200005],tree[600010];
LL z=1;

void build(int p,int L,int R){
    if(L==R){
        tree[p]=a[L];
        return;
    }
    int mid=(L+R)>>1;
    build(p<<1,L,mid);
    build(p<<1|1,mid+1,R);
    tree[p]=(tree[p<<1]&tree[p<<1|1]);
}

LL query(int p,int L,int R,int qL,int qR){
    if(qL>R||qR<L)return z;
    if(L>=qL&&R<=qR)return tree[p];
    int mid=(L+R)>>1;
    LL q1=query(p<<1,L,mid,qL,qR);
    LL q2=query(p<<1|1,mid+1,R,qL,qR);
    return (q1&q2);
}

int main(){
    int T;
    while(z<=1000000000)z*=2;
    z--;
    //ios_base::sync_with_stdio(false);
    //cin.tie(NULL);
    cin>>T;
    while(T--){
        int N;
        cin>>N;
        loop(i,1,N+1){
            cin>>a[i];
        }
        build(1,1,N);
        int q;
        cin>>q;
        loop(i,0,q){
            int b,c;
            cin>>b>>c;
            LL ans=query(1,1,N,b,c);
            cout<<ans<<"\n";
        }
    }
}

#include<bits/stdc++.h>
#define INF 1000000000
#define pii pair<int, int>
#define fi first
#define se second
#define pb push_back
#define ll long long
using namespace std;

ll datas[200005];
ll st[800105];

ll build(int pos, int L, int R)
{
	int mid=(L+R)/2;
	if(L==R)
	{
		st[pos]=datas[L];
		return st[pos];
	}
	return st[pos]=((build(pos*2, L, mid))&(build((pos*2)+1, mid+1, R)));
}

ll query(int pos, int L, int R, int S, int E)
{
	int mid=(L+R)/2;
	if(L > E || R < S) return 2147483647;
	if(L>=S && R<=E) return st[pos];
	ll h1=(query(2*pos, L, mid, S, E));
	ll h2=(query((2*pos)+1, mid+1, R, S, E));
//	cout<<h1<<" "<<h2<<endl;
	ll h=(h1&h2);
	return h;
}

int main()
{
	int tc;
	cin>>tc;
	for(int ntc=0;ntc<tc;ntc++)
	{
		int data;
		cin>>data;
		for(int a=1;a<=data;a++)
		{
			scanf("%lld", &datas[a]);
		}
		build(1, 1, data);
		int Q;
		cin>>Q;
		for(int a=0;a<Q;a++)
		{
			int L, R;
			scanf("%d %d", &L, &R);
			printf("%lld\n", query(1, 1, data, L, R));
		}
	}
 	return 0;
}


#include <bits/stdc++.h>
using namespace std;

int main()
{
	ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	int t; cin >> t;
	while(t--) {
		long long n, q; cin >> n;
		vector<long long> a(n);
		for(int i=0; i<n; i++) {
			cin >> a[i];
		}

		cin >> q;

		int co[200007] = {0};
		vector<pair<int, int> > query;
		for(int i=0; i<q; i++) {
			int l, r; cin >> l >> r; --l, --r;
			query.push_back({l, r});
			co[l]++; co[r]++;
		}

		int l = 0, f = 0; int ans;
		vector<pair<pair<int, int> , int > > v;
		for(int i=0; i<n; i++) {
			if (co[i] > 0) {
				if (f)
					v.push_back({{l, i-1}, ans});
					f = 0;
				v.push_back({{i, i}, a[i]});
			}
			else {
				if (f == 0)
					ans = a[i], f = 1, l = i;
				else {
					ans &= a[i];
				}
			}
		}

		for(auto it : query) {
			int point1, l = 0, r = v.size()-1;
			while(l <= r) {
				int mid = (l + r) / 2;
				if (v[mid].first.first < it.first)
					l = mid + 1;
				else if (v[mid].first.first > it.first)
					r = mid - 1;
				else {
					point1 = mid;
					break;
				}
			}

			int point2;l = 0, r = v.size()-1;
			while(l <= r) {
				int mid = (l + r) / 2;
				if (v[mid].first.second < it.second)
					l = mid + 1;
				else if (v[mid].first.second > it.second)
					r = mid - 1;
				else {
					point2 = mid;
					break;
				}
			}
			
			int ans = v[point1].second;
			for(int i=point1+1; i <= point2; i++) {
				ans &= v[i].second;
			}
			cout << ans << "\n";
		}
	}
}

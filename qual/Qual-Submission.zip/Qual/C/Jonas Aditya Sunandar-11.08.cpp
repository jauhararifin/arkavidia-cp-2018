#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef pair<int,ii> iii;
const int INF=(int)2e9;
const double EPS=(double)1e-9;
const double PI=(double)acos(-1.0);
const ll MOD=(ll)1e9+7;

#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define FOR(i,n) for(int i=0;i<n;i++)
#define REPP(i,l,r,c) for(int i=l;i<=r;i+=c)
#define REP(i,l,r) REPP(i,l,r,1)
#define FORD(i,n) for(int i=n-1;i>=0;i--)
#define REVV(i,l,r,c) for(int i=max(l,r),_m=min(l,r);i>=_m;i-=c)
#define REV(i,l,r) REVV(i,l,r,1)
#define MAX 1000005
#define LEFT 2*node
#define RIGHT 2*node+1
#define wa cout<<"wa"<<endl;
ll arr[200005], segment[MAX];

void base(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
}

ll build(int l,int r,int node){
	segment[node] = 0;
	if (l==r){
		segment[node] = arr[l];
		return arr[l];
	}
	int mid = (l+r)/2;
	ll a = build(l,mid,node*2);
	ll b = build(mid+1,r,node*2+1);
	return segment[node] = (a&b);
}

ll query(ll l,ll r,ll node,ll x,ll y){
	if ((x==l && y==r)) return segment[node];
	ll mid = (l+r)/2;
	ll ans;
	if (l<=x && y<=mid){//kiri
		ans = query(l,mid,2*node,x,y);
	}else if (mid+1<=x && y<=r){//kanan
		ans = query(mid+1,r,2*node+1,x,y);
	}else {//merge
		ll a = query(l,mid,2*node,x,mid);
		if (a==0) return 0;
		ll b = query(mid+1,r,2*node+1,mid+1,y);
		ans = (a&b);
	}
	return ans;
}

int main(){
	//base();
	int t;
	scanf("%d",&t);
	while(t--){
		int n;
		scanf("%d",&n);
		for(int i=1; i<=n; i++){
			scanf("%lld",&arr[i]);
		}
		build(1,n,1);
		ll q;
		scanf("%lld",&q);
		while(q--){
			ll a,b;
			scanf("%lld %lld",&a,&b);
			printf("%lld\n",query(1,n,1,a,b));
		}
	}
	return 0;
}



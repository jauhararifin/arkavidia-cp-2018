#include <bits/stdc++.h>
using namespace std;

int arr[200005];
int st[800005];

void build(int i, int l, int r){
	if(l == r){
		st[i] = arr[l];
	}else{
		int c = (l+r)>>1;
		int li = (i<<1) + 1;
		int ri = (i<<1) + 2;

		build(li, l, c);
		build(ri, c+1, r);

		st[i] = st[li]&st[ri];
	}
}

int query(int i, int l, int r, int L, int R){
	int ret;
	if(L <= l && r <= R){
		ret = st[i];
	}else if(R < l || r < L){
		ret = (1LL<<31)-1;
	}else{
		int c = (l+r)>>1;
		int li = (i<<1) + 1;
		int ri = (i<<1) + 2;

		ret = query(li, l, c, L, R) & query(ri, c+1, r, L, R);
	}
	return ret;

}

int main(){
	int qt;
	scanf("%d", &qt);

	while(qt--){
		int n, q;
		scanf("%d", &n);

		for (int i = 0; i < n; i++){
			scanf("%d", &arr[i]);
		}

		scanf("%d", &q);

		build(0, 0, n-1);
		for (int i = 0; i < q; i++){
			int l, r;
			scanf("%d%d", &l, &r);
			l--; r--;

			printf("%d\n", query(0, 0, n-1, l, r));
		}
	}
}
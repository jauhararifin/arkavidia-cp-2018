#include <stdio.h>
#include <iostream>
#include <vector>
using namespace std;
int n;
long long int ar[200005];
long long int tree[600000];
int ql, qr;
void build(int l, int r, int k)
{
    if (l==r)
    {
        tree[k]=ar[l];
    }
    else
    {
        build(l,(l+r)/2,k*2);
        build((l+r)/2+1,r,k*2+1);
        tree[k]=tree[k*2]&tree[k*2+1];
    }
}
long long int queer(int l, int r, int k)
{
    if (ql<=l&&qr>=r)
    {
        return tree[k];
    }
    if (ql>r||qr<l)
    {
        return (1<<30)-1;
    }
    return queer(l,(l+r)/2,k*2)&queer((l+r)/2+1,r,k*2+1);
}
int main()
{
    int tc;
    cin>>tc;
    while (tc--)
    {
        cin>>n;
        for (int i=0;i<n;i++)
        {
            cin>>ar[i];
        }
        build(0,n-1,1);
        int m;
        cin>>m;
        while (m--)
        {
            cin>>ql>>qr;
            ql--;
            qr--;
            printf ("%lld\n",queer(0,n-1,1));
        }
    }
}

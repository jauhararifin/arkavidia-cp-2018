#include <bits/stdc++.h>

using namespace std;

long long int arr[200005];
long long int tree[600015];

long long int searchs(int qLow, int qHigh, int low, int high, int pos=0) {
    if(qLow <= low and high <= qHigh) {
        return tree[pos];
    }
    if(qLow > high or qHigh < low) return -1;

    int mid = (low + high) / 2;

    long long int a = searchs(qLow, qHigh, low, mid, pos*2+1);
    long long int b = searchs(qLow, qHigh, mid+1, high, pos*2+2);

    if(a == -1) {
        return b;
    }
    if(b == -1) {
        return a;
    }

    return (long long int) a & b;
}

void build(int low,int high,int pos=0) {
    if(low == high) {
        tree[pos] = arr[low];
        return ;
    }
    int mid = (low + high) / 2;
    build(low, mid, pos*2+1);
    build(mid+1, high, pos*2+2);
    tree[pos] = (long long int) (tree[pos*2+1] & tree[pos*2+2]);
}

int main() {
    int t;
    cin >> t;

    while(t--) {
        long long int n, q;
        cin >> n;
        for(int i=0; i<n; i++) {
            cin >> arr[i];
        }

        build(0, n);
        cin >> q;
        for(int i=0; i<q; i++) {
            long long int a, b;
            cin >> a >> b;
            cout << searchs(a-1, b-1, 0, n, 0) << endl;
        }
    }
}


#include<bits/stdc++.h>
using namespace std;
int arr[200010];
int dat[600000];
void build (int node, int starts, int ends)
{
	
	if(ends==starts)
	{
		dat[node]=arr[starts];
		return;	
	}
	
	else
	{
		int mid= (starts+ends)/2;
		build(2*node,starts,mid);
		build(2*node+1,mid+1,ends);
		dat[node]=dat[2*node]&dat[2*node+1];
		return;
	}
} 


int query(int node,int starts,int ends,int l,int r)
{
	if(starts>r || ends<l)return (1<<30)-1;
	else if(starts>=l && ends<=r)
	{
//		cout<<l<<" "<<r<<" "<<dat[node]<<endl;
		return dat[node];
	} 
	else
	{
		int mid= (starts+ends)/2;
		int ans=(1<<30)-1;
//		cout<<"qq "<<query(2*node,starts,mid,l,r)<<endl;
		ans=ans&query(2*node,starts,mid,l,r);
		ans=ans&query(2*node+1,mid+1,ends,l,r);
//		cout<<" >> "<<ans<<endl;
		return ans;
	}
}


int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int bd;
		scanf("%d",&bd);
		for(int i=1;i<=bd;i++)
		{
			scanf("%d",&arr[i]);
		}
		build(1,1,bd);
		int qq;
		scanf("%d",&qq);
		for(int j=1;j<=qq;j++)
		{
			int l,r;
			scanf("%d%d",&l,&r);
			printf("%d\n",query(1,1,bd,l,r));
		}
	}
return 0;
}


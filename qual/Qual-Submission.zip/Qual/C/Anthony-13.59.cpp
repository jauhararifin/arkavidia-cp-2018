#include <stdio.h>

struct tree{
	long long int idmin, idmax;
	long long int n;
};

tree test[1 << 20];
long long int idTree[1 << 20];
long long int arr[1 << 20];

void segmentedTree(int id, int min, int max){  //urutan parameter, id tree, id array min, id array max
    test[id].idmin = min;
    test[id].idmax = max;

    if(min == max){ //udah sampe leaf node
        test[id].n = arr[min];
        idTree[min] = id;
    }
    else{
        int mid = (min + max) / 2;
        segmentedTree(id*2, min, mid);  //anak kiri
        segmentedTree(id*2+1, mid+1, max); //anak kanan
        test[id].n = test[id*2].n & test[id*2+1].n;
    }
}

long long int solve(int id, int min, int max){
	if(max < test[id].idmin || min > test[id].idmax) return -1;
	if(min <= test[id].idmin && max >= test[id].idmax){
		return test[id].n;
	}

	long long int left, right;
	left = solve(id*2, min, max);
	right = solve(id*2+1, min, max);
	return left & right;
}

int main(){
	int tc, a, b, n, q, leaf;
	scanf("%d", &tc);
	while(tc--){
		for(int i = 0; i<=200100; i++){
			arr[i] = -1;
		}
		scanf("%d", &n);
		for(int i = 0; i<n; i++){
			scanf("%lld", &arr[i]);
		}
		
		leaf = 1;
		while(leaf < n){
			leaf *= 2;
		}
		segmentedTree(1, 0, leaf-1);
		scanf("%d", &q);
		while(q--){
			scanf("%d %d", &a, &b);
			printf("%lld\n", solve(1, a-1, b-1));
		}
	}
	return 0;
}

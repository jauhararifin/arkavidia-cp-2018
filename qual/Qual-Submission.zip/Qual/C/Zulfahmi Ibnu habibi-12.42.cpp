// Bismillahirohmanirohiim

#include<bits/stdc++.h>
using namespace std;

#define nl "\n"
#define PB push_back
#define SZ size()
#define ios ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL)
#define F first
#define S second
#define LEN length()
long long arr[200002][34];
long long duapang[34];
void bersih()
{
    for(int i=0;i<200002;i++)
        for(int j=0;j<34;j++)
            arr[i][j]=0;
}
void pre()
{
    duapang[0]=1;
    duapang[1]=2;
    for(long long i=2;i<=33;i++)
    {
        duapang[i]=duapang[i-1]*2 ;
    }
}

int main()
{
    ios;
    pre();
    long long t,n,q,x,y;
    cin >> t;
    while(t--)
    {
        bersih();
        cin >> n ;
        for(long long i=1;i<=n;i++)
        {
            int j=0;
            cin >> x ;
            while(x>0)
            {
                if(x%2!=0) arr[i][j]=arr[i-1][j]+1;
                else arr[i][j]=arr[i-1][j] ;
                x=x/2;
                j++;
            }
        }
        long long q ;
        cin >> q ;
        for(int i=0;i<q;i++)
        {
            cin >> x >> y ;
            long long ans=0,aw=y-x+1;
            for(int i=0;i<=33;i++)
            {
                if(arr[y][i]-arr[x-1][i]==aw)
                {
                    ans+= duapang[i];
                }
            }
            cout << ans << nl ;
        }
    }
}

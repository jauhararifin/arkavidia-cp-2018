#include<bits/stdc++.h>

using namespace std;

int arr[200005][40];
int main() {
    int tt;
    scanf("%d", &tt);
    while(tt--) {
        int n;
        scanf("%d", &n);
        for (int i=0;i<=n;i++) {
            for (int j=0;j<35;j++) {
                arr[i][j] = 0;
            }
        }
        for (int i=0;i<n;i++) {
            int xx;
            scanf("%d", &xx);
            int cnt = 0;
            while(xx) {
                arr[i+1][cnt] += xx&1;
                xx>>=1;
                cnt++;
            }
            for (int j=0;j<35;j++) {
                arr[i+2][j] = arr[i+1][j];
            }
        }
        // for (int i=0;i<n;i++) {
        //     for (int j=0;j<5;j++)  {
        //         printf("%d ", arr[i+1][j]);
        //     }
        //     printf("\n");
        // }
        int q;
        scanf("%d", &q);
        while(q--) {
            int a,b;
            scanf("%d%d", &a, &b);
            int ans[40];
            int output = 0;
            int times = 1;
            for (int i=0;i<35;i++) {
                ans[i] = arr[b][i] - arr[a-1][i];
                if (ans[i] == b-a+1) output+=times;
                times*=2;
            }
            printf("%d\n", output);
        }
    }
}
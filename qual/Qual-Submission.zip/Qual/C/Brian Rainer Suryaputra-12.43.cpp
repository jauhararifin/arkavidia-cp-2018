#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int bx = 32;
ll t,n,x,q,l,r,a;
ll bit[bx][200005];

void update(ll tmp, ll val){
	int pos = 0;
	for(int pos=bx-1;pos>=0;pos--){
		if((val&(1<<pos))) {
			int idx = tmp;
			while(idx<=n){
				bit[pos][idx]++;
				idx+=(idx&-idx);
			}
		}
	}
}

ll query(int idx, int pos){
	ll q=0;
	while(idx>0){
		q+=bit[pos][idx];
		idx-=(idx&-idx);
	}
	return q;
}

int main(){
	cin>>t;
	while(t--){
		memset(bit,0,sizeof(bit));
		cin>>n;
		for(int i=1;i<=n;i++){
			cin>>a;
			update(i,a);
//			for(int j=bx-1;j>=0;j--){
//				cout<<query(i,j)<<" ";
//			} cout<<endl;
		}
		
		cin>>q;
		while(q--){
			cin>>l>>r;
			ll res = 0ll;
//			for(int j=bx-1;j>=0;j--){ cout<<query(l-1,j)<<" "; } cout<<endl;
//			for(int j=bx-1;j>=0;j--){ cout<<query(r,j)<<" "; } cout<<endl;
			ll diff = r-l+1;
			for(int j=bx-1;j>=0;j--){
				int low=query(l-1,j);
				int high=query(r,j);
//				cout<<high-low<<" ";
				if((high-low)==diff){
					res|=1ll<<j;
				}
			}
			cout<<res<<endl;
		}
	}
	return 0;
}

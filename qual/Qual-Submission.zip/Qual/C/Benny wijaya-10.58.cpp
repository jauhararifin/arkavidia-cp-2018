#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

#define pb push_back
#define mp(x,y) make_pair(x,y)
#define scd(n) scanf("%d",&n)
#define sclf(n) scanf("%lf",&n)
#define scl(n) scanf("%I64d",&n)
#define repi(a,b,c) for(int i=a;i<b;i+=c)
#define repis(a,b,c) for(int i=a-1;i>=b;i-=c)
#define repj(a,b,c) for(int j=a;j<b;j+=c)
#define repjs(a,b,c) for(int j=a-1;j>=b;j-=c)
#define repk(a,b,c) for(int k=a;k<b;k+=c)
#define repks(a,b,c) for(int k=a-1;k>=0;k-=c)
#define fi first
#define se second

/*
 fast I/O

ios::sync_with_stdio(0);
cin.tie();

 freeopen

 freopen("input.txt","r",stdin);
 freopen("output.txt","w",stdout);
 */

typedef pair<ll,ll> ii;
const int mx = 200100;
const int md = 1e9+7;
const double EULER = 2.71828182845904523536;

bool compare(const pair<int,int>& a,const pair <int,int>& b) {
    return a.first > b.first || (a.first == b.first && a.second < b.second);
}

ull ans=0;
ll arr[mx],tree[mx*3];
int n,m,a,b;


ll searchs(int qLow,int qHigh,int low,int high,int pos=0) {
    if(qLow <= low and high <= qHigh) {
        return tree[pos];
    }
    if(qLow > high or qHigh < low) return -1;

    int mid = (low+high)/2;
    ll e = searchs(qLow,qHigh,low,mid,pos*2+1);
    ll ee = searchs(qLow,qHigh,mid+1,high,pos*2+2);
    if(e == -1) return ee;
    if(ee == -1) return e;
    return e&ee;
}

void build(int low,int high,int pos=0) {
    if(low == high) {
        tree[pos] = arr[low];
        return ;
    }
    int mid = (low+high)/2;
    build(low,mid,pos*2+1);
    build(mid+1,high,pos*2+2);
    tree[pos] = tree[pos*2+1] & tree[pos*2+2];
}


int main() {
    ios::sync_with_stdio(0);
    cin.tie();
    int t;
    cin >> t;
    while(t--) {
        cin >> n;
        repi(0,n,1) cin >> arr[i];
        build(0,n-1);
        cin >> m;
        while(m--) {
            cin >> a >> b;
            cout << searchs(a-1,b-1,0,n-1) << endl;
        }
    }
}

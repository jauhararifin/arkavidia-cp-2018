#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef pair<double, double> pdd;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<pii> vii;

#define newline '\n';
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define FAST_IO  ios_base::sync_with_stdio(false)

const int PI = acos(-1.0);
const int MOD = 1e9 + 7;

ll power(ll a, int b) {
	if (b == 0) return 1LL;
	if (b == 1) return a % MOD;
	ll ret = power(a, b / 2) % MOD;
	ret = (ret * ret) % MOD;
	if (b & 1) ret = (ret * a) % MOD;
	return ret;
}

void tests() {
	assert(power(2, 10) == 1024);
}

const int MAX_N = 2e5 + 5;

int prefix[MAX_N][32];
int arr[MAX_N];

void solve() {
	int N;
	cin >> N;
	for (int i = 1; i <= N; ++i) {
		cin >> arr[i];
	}

	for (int i = 0; i < 32; ++i) {
		for (int j = 1; j <= N; ++j) {
			prefix[j][i] = prefix[j-1][i];
			if ((1 << i) & arr[j]) ++prefix[j][i];
		}
	}

	int Q;
	cin >> Q;

	while (Q--) {
		int L, R;
		cin >> L >> R;
		bitset<32> bs;
		bs.reset();
		for (int i = 0; i < 32; ++i) {
			if (prefix[R][i] - prefix[L-1][i] == R - L + 1) {
				bs.set(i);
			}
		}
		int ans = 0;
		for (int i = 0; i < 32; ++i) {
			if (bs[i]) ans += (1 << i);
		}
		cout << ans << '\n';
	}
}

int main() {
	FAST_IO;

	int tc;
	cin >> tc;
	while(tc--) {
		solve();
	}

	return 0;
}

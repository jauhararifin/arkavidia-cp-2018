#include<bits/stdc++.h>
#define fi first
#define se second
#define pb push_back
#define pob pop_back
#define mp make_pair
#define FOR(i,n) for (int i=0;i<n;i++)
#define REP(i,l,r) for (int i=l;i<r;i++)
#define REPS(i,l,r) for (int i=l;i<=r;i++)
#define FORD(i,n) for (int i=n-1;i>=0;i--)
#define REPD(i,l,r) for (int i=r-1;i>=l;i--)
#define REPDS(i,l,r) for (int i=r;i>=l;i--)
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;

const int INF=(int)1E9;
const ll INFLL=(ll)1E15;
const double INFD=1E9;
const ll MOD=(ll)1E9+7;
const double PI=acos(-1);
const double EPS=1E-9;

bool between(int x,int l,int r) {
	return (l<=x && x<=r);
}

string tostring(int x) {
	char dum[20]; sprintf(dum,"%d",x);
	string ret(dum); return ret;
}

ll n,q,l,r;
ll A[200010];
ll psum[32][200010];

int main() {
	ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int kasus; cin>>kasus;
	while (kasus--) {
		cin>>n; FOR(i,n) cin>>A[i];
		memset(psum,0,sizeof psum);
		FOR(i,32) {
			psum[i][0]=(A[0]&(1<<i))!=0;
			REP(j,1,n) psum[i][j]=psum[i][j-1]+((A[j]&(1<<i))!=0);
		}
		cin>>q; while (q--) {
			cin>>l>>r; l--; r--;
			ll ans=0;
			FOR(i,32) {
				int cnt=psum[i][r];
				if (l!=0) cnt-=psum[i][l-1];
//				cout<<i<<" "<<cnt<<endl;
				if (cnt!=(r-l+1)) continue;
				ans+=(1<<i);
			}
			cout<<ans<<endl;
		}
	}
	return 0;
}

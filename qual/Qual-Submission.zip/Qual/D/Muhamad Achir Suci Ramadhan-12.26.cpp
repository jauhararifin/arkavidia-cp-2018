#include <iostream>
#include <string.h>
#include <algorithm>

#define lo long long
using namespace std;

lo t,tab[100100],dp[100100];
lo n,k;
const lo inf = 1e17 + 10;
int main()
{
	cin>>t;
	
	while(t--)
	{
		memset(dp,0,sizeof(dp));
		memset(tab,0,sizeof(tab));
		cin>>n>>k;
		for (int i=1;i<=n;i++) cin>>tab[i];
		
		sort(tab+1,tab+n+1);
		
		dp[0]=0;
		tab[0]=tab[k];
		for (int i=1;i<k;i++) dp[i]=inf;
		for (int i=k;i<=n;i++)
		{
			dp[i]=min(dp[i-1] + tab[i]-tab[i-1], dp[i-k] + tab[i]-tab[i-k+1]);
			//cout<<i<<" "<<dp[i]<<endl;
		}
		
		cout<<dp[n]<<endl;
	}
	
	return 0;
}

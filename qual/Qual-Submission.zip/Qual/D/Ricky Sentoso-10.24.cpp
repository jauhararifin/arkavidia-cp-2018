#include<bits/stdc++.h>
using namespace std;
#define LL long long
#define ULL unsigned LL
#define PII pair<int,int>
#define VI vector<int>
#define VPII vector< PII >
#define VVI vector< VI >
#define PB push_back
#define F first
#define S second
const LL INF=1e17;
const int MOD=1e9+7;
int t,n,k,a[100000];
LL dp[100000][2];
LL f(int x,int y){
    if(x>=n)return (y==0)?0:INF;
    if(dp[x][y]!=-1)return dp[x][y];
    LL ret=INF;
    if(y==0){
        if(x+k-1<n)ret=min(ret,f(x+k-1,1)-a[x]);
    }
    else{
        ret=min(ret,f(x+1,1));
        ret=min(ret,f(x+1,0)+a[x]);
    }
    return dp[x][y]=ret;
}
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&n,&k);
        for(int i=0;i<n;i++)scanf("%d",&a[i]);
        sort(a,a+n);
        memset((dp),-1,sizeof(dp));
        LL ans=f(0,0);
        printf("%lld\n",ans);
    }
    return 0;
}

#include<bits/stdc++.h>
using namespace std;
#define INF 1000000001

int tc;
int n,k;
int a[100005];
int sel[100005];
int memo[100005];
bool vis[100005];

int dp(int id)
{
	if(id>n) return -INF;
	if(id==n) return 0;
	if(vis[id]) return memo[id];
	vis[id]=1;
	return memo[id]=max(dp(id+k)+sel[id],dp(id+1));
}

int main()
{
	scanf("%d",&tc);
	sel[0]=0;
	while(tc--)
	{
		memset(vis,0,sizeof(vis));
		scanf("%d%d",&n,&k);
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
		}
		sort(a+1,a+n+1);
		for(int i=1;i<n;i++)
		{
			sel[i]=a[i+1]-a[i];
		}
		sel[n]=0;
		int ans=dp(k);
		printf("%d\n",a[n]-a[1]-ans);
	}
 	return 0;
}


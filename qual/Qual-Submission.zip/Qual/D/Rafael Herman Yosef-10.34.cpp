#include<stdio.h>
#include<sstream>
#include<iostream>

#include<math.h>
#include<algorithm>
#include<utility>
#include<string.h>
#include<string>
#include<stdlib.h>
#include<assert.h>
#include<time.h>

#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>

#define FI first
#define SE second
#define PB push_back
#define MP make_pair
#define endl '\n'
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

void desperate_optimization(int precision){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(precision);
}

ll arr[100005];
ll dp[100005];
ll BIT[100005];
int n,k;

deque<ll> deq;

ll query(int n){
	if(n < 0) return 1e18;
	if(n == 0) return BIT[0];
	ll ans = BIT[0];
	for(;n>0;n-=(n&-n)) ans = min(ans,BIT[n]);
	return ans;
}

void update(int x,ll v){
	for(;x<=n;x+=(x&(-x))) BIT[x] = min(BIT[x],v);
}

int main(){
	desperate_optimization(10);
	int ntc;
	cin>>ntc;
	while(ntc--){
		cin>>n>>k;
		for(int i=1;i<=n;i++) cin>>arr[i];
		for(int i=1;i<=n;i++) BIT[i] = 1e18;
		sort(arr+1,arr+n+1);
		BIT[0] = -arr[1];
		for(int i=1;i<=n;i++){
			ll ans = query(i-k);
			dp[i] = ans + arr[i];
		//	cout<<i<<" "<<ans<<" "<<dp[i]<<endl;
			update(i,dp[i] - arr[i + 1]);
		}
		//for(int i=1;i<=n;i++) cout<<i<<" "<<BIT[i]<<endl;
		cout<<dp[n]<<endl;
	}
	return 0;
}


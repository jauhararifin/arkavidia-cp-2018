#include<bits/stdc++.h>
using namespace std;
long long data[100005],selisih[100005];
long long memo[100005];
long long n,k;

long long dp(long long pos)
{
	if(pos>=n)return -1000000000;
	if(pos==n-1)return 0;
	if(memo[pos]!=-1)return memo[pos];
	return memo[pos]=max(dp(pos+k)+selisih[pos],dp(pos+1));
}

int main()
{
int t;
scanf("%d",&t);
while(t--)
{
	memset(memo,-1,sizeof(memo));
	scanf("%d%d",&n,&k);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&data[i]);
	}
	sort(data,data+n);
	for(int i=0;i<n-1;i++)
	{
		selisih[i]=data[i+1]-data[i];
	}
//	cout<<dp(k-1)<<endl;
	cout<<data[n-1]-data[0]-dp(k-1)<<endl;
}
return 0;
}


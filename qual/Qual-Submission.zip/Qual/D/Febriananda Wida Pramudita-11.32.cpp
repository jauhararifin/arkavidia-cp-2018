#include<bits/stdc++.h>
using namespace std;

#define maxn 200000
#define ll long long
ll dp[maxn + 5], qq[maxn + 5], minqq[maxn + 5], ar[maxn + 5]; 

int main() {
	int tes, n, m;
	scanf("%d", &tes);
	while(tes--) {
		scanf("%d %d", &n, &m);
		for(int i = 1; i <= n; i++) {
			scanf("%lld", &ar[i]);
		}
		sort(ar + 1, ar + n + 1);
		// for(int i = 1; i <= n; i++) {
		// 	cout << ar[i] << " ";
		// }
		// cout << "\n";
		for(int i = 0; i < m; i++) {
			qq[i] = -ar[i + 1];
			minqq[i] = qq[i];
			minqq[i] = minqq[0];
		}
		for(int i = m; i <= n; i++) {
			dp[i] = minqq[i - m] + ar[i];
			qq[i] = dp[i] - ar[i + 1];
			minqq[i] = qq[i];
			minqq[i] = min(minqq[i], minqq[i - 1]);
		}
		// for(int i = 1; i <= n; i++) {
		// 	cout << qq[i] << " ";
		// }
		// cout << "\n";
		// for(int i = 1; i <= n; i++) {
		// 	cout << dp[i] << " ";
		// }
		// cout << "\n";
		printf("%lld\n", dp[n]);
	}
}
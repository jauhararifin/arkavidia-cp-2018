//D
/*==========================================================*/
/*    Template ver 2017-0720    |    Created by JollyBee    */
/* DOMINUS pascit me, et nihil mihi deerit (Psalmorum 23:1) */
/*==========================================================*/
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef vector<pii> vii;
const double EPS=(double)1e-9;
const double PI=(double)acos(-1.0);
#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define pob pop_back
#define pf push_front
#define pof pop_front
#define FOR(i,n) for(int i=0;i<n;i++)
#define REPP(i,l,r,c) for(int i=l;i<=r;i+=c)
#define REP(i,l,r) REPP(i,l,r,1)
#define FORD(i,n) for(int i=n-1;i>=0;i--)
#define REVV(i,l,r,c) for(int i=l;i>=r;i-=c)
#define REV(i,l,r) REVV(i,l,r,1)
//random
int irand(int lo, int hi){
	return (((double)rand())/(RAND_MAX+1.0)) * (hi-lo+1) + lo;
}
//ll to string
string toString(ll x) {
	stringstream ss;
	ss << x;
	return ss.str();
}
//string to ll
ll toNumber(string S) {
	ll ret; 
	sscanf(S.c_str(),"%lld",&ret); 
	return ret;
}
// std::fill(start, end, value);
// for(auto it: DS){}

const int INF=(int)2e9;
const ll OO=(ll)1e17;
const ll MOD=(ll)1e9+7;
/*==========================================================*/
/*                     END OF TEMPLATE                      */
/* DOMINUS pascit me, et nihil mihi deerit (Psalmorum 23:1) */
/*==========================================================*/

struct SegTree{
	ll n,dat[800005];
	
	void __upd(int idx, int l, int r, int pos, ll val){
		if(l==r){ dat[idx]=val; return; }
		int mid=(l+r)>>1;
		if(pos<=mid)__upd(2*idx,l,mid,pos,val);
		else __upd(2*idx+1,mid+1,r,pos,val);
		dat[idx]=min(dat[2*idx],dat[2*idx+1]);
	}
	ll __que(int idx, int l, int r, int a, int b){
		if(l>r || b<l || r<a)return OO;
		if(a<=l && r<=b)return dat[idx];
		//reccurence
		int mid=(l+r)>>1;
		return min(__que(2*idx,l,mid,a,b),__que(2*idx+1,mid+1,r,a,b));
	}
	
	void reset(int _n){ n=_n; FOR(i,800003)dat[i]= OO; }
	inline void upd(int pos, ll val){ __upd(1,0,n,pos,val); }
	inline ll que(int l, int r){ return __que(1,0,n,l,r); }
} DS;

ll dat[100005];
ll dp[100005];

int main(){
	int t,n,k;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&k);
		DS.reset(n);
		REP(i,1,n)scanf("%lld",dat+i);
		sort(dat+1,dat+1+n); dat[n+1]=0;
		DS.upd(0,-dat[1]);
		REP(i,k,n)DS.upd(i,DS.que(0,i-k)+dat[i]-dat[i+1]);
		fprintf(stderr,"     << ");
		printf("%lld\n",DS.que(n,n));
	}
	return 0;
}

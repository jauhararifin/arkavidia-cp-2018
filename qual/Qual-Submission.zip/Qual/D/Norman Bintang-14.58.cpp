#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int INF = 1000000000;

int TC, k, n, arr[100009];
int memo[100009][2];

int f(int flag, int idx) {
    if (idx == 0 && flag == 1) return 0;
    if (idx <= 0) return INF;

    int &ret = memo[idx][flag];
    if (ret != -INF) return ret;

    if (flag == 1) {
        ret = arr[idx] + f(0, idx - k + 1);
    } else {
        int ret1 = f(0, idx - 1);
        int ret2 = f(1, idx - 1) - arr[idx];
        ret = (ret1 < ret2) ? ret1 : ret2;
    }
    return ret;
}

void reset() {
    for (int i = 0; i <= n; i++) {
        memo[i][0] = memo[i][1] = -INF;
    }
}

int main() {
    scanf("%d", &TC);
    while (TC--) {
        scanf("%d %d", &n, &k);
        for (int i = 1; i <= n; i++) {
            scanf("%d", &arr[i]);
        }
        if (k == 1) {
            printf("0\n");
            continue;
        }
        reset();
        sort(arr + 1, arr + 1 + n);
        printf("%d\n", f(1, n));
    }
}

#include<bits/stdc++.h>
#define fi first
#define se second
#define pb push_back
#define pob pop_back
#define mp make_pair
#define FOR(i,n) for (int i=0;i<n;i++)
#define REP(i,l,r) for (int i=l;i<r;i++)
#define REPS(i,l,r) for (int i=l;i<=r;i++)
#define FORD(i,n) for (int i=n-1;i>=0;i--)
#define REPD(i,l,r) for (int i=r-1;i>=l;i--)
#define REPDS(i,l,r) for (int i=r;i>=l;i--)
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;

const int INF=(int)1E9;
const ll INFLL=(ll)1E15;
const double INFD=1E9;
const ll MOD=(ll)1E9+7;
const double PI=acos(-1);
const double EPS=1E-9;

bool between(int x,int l,int r) {
	return (l<=x && x<=r);
}

string tostring(int x) {
	char dum[20]; sprintf(dum,"%d",x);
	string ret(dum); return ret;
}

int n,m;
int A[100010];
int DP[100010];

int f(int cur) {
	if (cur>n-1) return -INF;
	if (cur==n-1) return 0;
	int &ret=DP[cur];
	if (ret!=-1) return ret;
	return ret=max(A[cur+1]-A[cur]+f(cur+m),f(cur+1));
}

int main() {
	ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int kasus; cin>>kasus;
	while (kasus--) {
		cin>>n>>m; FOR(i,n) cin>>A[i]; sort(A,A+n);
		memset(DP,-1,sizeof DP);
		int ans=A[n-1]-A[0]; ans-=f(m-1);
		cout<<ans<<endl;
	}
	return 0;
}

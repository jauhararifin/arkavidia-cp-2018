#include <bits/stdc++.h>

#define fi first
#define se second
#define sz(a) (int)(a).size()
#define all(a) (a).begin(), (a).end()
#define reset(a, v) memset((a), v, sizeof (a))

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef vector<ii> vii;

const int N = 123456;
const ll INF = (ll)1e+15;

int n, k;
ll dat[N];
ll dp[N];
ll tree[N*4];

/*void build(int id, int L, int R) {
	tree[id] = INF;
	if (L == R) return;
	int mid = (L+R)>>1;
	build(id << 1, L, mid);
	build(id << 1 | 1, mid + 1, R);
	tree[id] = min(tree[id << 1], tree[id << 1 | 1]);	
}

void update(int id, int L, int R, int pos, ll val) {
	if (L == R) {
		tree[id] = val;
		return;
	}
	int mid = (L+R)>>1;
	if (pos <= mid) update(id << 1, L, mid, pos, val);
	else update(id << 1 | 1, mid + 1, R, pos, val);
	tree[id] = min(tree[id << 1], tree[id << 1 | 1]);
}

ll query(int id, int L, int R, int x, int y) {
	if (x <= L && R <= y) return tree[id];
	int mid = (L+R)>>1;
	ll ret = INF;
	if (x <= mid) ret = min(ret, query(id << 1, L, mid, x, y));
	else ret = min(ret, query(id << 1 | 1, mid + 1, R, x, y));
	return ret;
}*/

ll solve() {
	ll mini = INF;
	for (int cur = k; cur <= n; ++cur) {
		if (cur < k*2) {
			dp[cur] = dat[cur] - dat[1];
			//printf("dp[%d] = %lld\n", cur, dp[cur]);
			continue;
		}
		mini = min(mini, dp[cur-k] - dat[cur-k+1]);
		dp[cur] = dat[cur] + mini;
		//printf("dp[%d] = %lld\n", cur, dp[cur]);
	}
	return dp[n];
}

inline void Reset() {
	reset(dat,0); reset(dp,0);
}

int main() {
	int tc; scanf("%d", &tc);
	while (tc--) {
		scanf("%d %d", &n, &k);
		for (int i = 1; i <= n; ++i) scanf("%lld", &dat[i]);
		sort(dat + 1, dat + 1 + n);
		printf("%lld\n", solve());
		Reset();
	}
	return 0;
}
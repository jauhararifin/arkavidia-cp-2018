#include <bits/stdc++.h>
using namespace std;

const long long INF = 100000000000000;

int arr[100005];
long long memo[100005];

int main(){
	int qt;
	scanf("%d", &qt);

	while(qt--){
		int n, k;
		scanf("%d%d", &n, &k);

		for (int i = 0; i < n; i++){
			scanf("%d", &arr[i]);
		}

		sort(arr, arr+n);

		arr[n] = 0;
		memo[n] = 0;
		for (int i = n-1; i > n-k; i--) memo[i] = INF;
		long long curr = INF;

		for (int i = n-k; i >= 0; i--){
			int j = i+k;
			curr = min(curr, memo[j] + arr[j-1]);
			memo[i] = curr-arr[i];
		}

		printf("%lld\n", memo[0]);
	}
}
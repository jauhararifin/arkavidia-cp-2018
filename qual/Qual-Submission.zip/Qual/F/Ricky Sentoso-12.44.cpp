#pragma GCC optimize("O3")
#include<bits/stdc++.h>
using namespace std;
#define LL long long
#define ULL unsigned LL
#define PII pair<int,int>
#define VI vector<int>
#define VPII vector< PII >
#define VVI vector< VI >
#define PB push_back
#define F first
#define S second
const int INF=1e9;
const int MOD=1e9+7;
const double PI = acos(-1);
typedef std::complex<double> Complex;
typedef std::valarray<Complex> CArray;
void fft(CArray& x)
{
  const size_t N = x.size();
  if (N <= 1) return;
  CArray even = x[std::slice(0, N/2, 2)];
  CArray  odd = x[std::slice(1, N/2, 2)];
  fft(even);
  fft(odd);
  for (size_t k = 0; k < N/2; ++k)
  {
    Complex t = std::polar(1.0, -2 * PI * k / N) * odd[k];
    x[k    ] = even[k] + t;
    x[k+N/2] = even[k] - t;
  }
}
void ifft(CArray& x)
{
  x = x.apply(std::conj);
  fft( x );
  x = x.apply(std::conj);
  x /= x.size();
}
int t,n,q,a[50000],b[50000],cou_a[1<<16],cou_b[1<<16],two;
vector<LL> multiply(){
  int N;
  N=two;
  int padded_size = 2 * (1 << int(ceil(log2(N))));
  vector<Complex> num1_vec(padded_size - N, 0.0), num2_vec(padded_size - N, 0.0);
  for(int i = 0; i < N; i++) {
    double coeff;
    coeff=cou_a[i];
    num1_vec.push_back(coeff);
  }
  for(int i = 0; i < N; i++) {
    double coeff;
    coeff=cou_b[i];
    num2_vec.push_back(coeff);
  }
  CArray data1(padded_size);
  for(int i = 0; i < padded_size; i++) data1[i] = num1_vec[i];
  CArray data2(padded_size);
  for(int i = 0; i < padded_size; i++) data2[i] = num2_vec[i];
  fft(data1);
  fft(data2);
  CArray data3(padded_size);
  data3 = data1 * data2;
  ifft(data3);
  vector<long long> ans;
  for (int i = 0; i < padded_size - 1; i++) {
    ans.push_back((long long)(round(data3[i].real())));
  }
  return ans;
}
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        memset((cou_a),0,sizeof(cou_a));
        int maxi=0;
        for(int i=0;i<n;i++){
            scanf("%d",&a[i]);
            cou_a[a[i]]++;
            maxi=max(a[i],maxi);
        }
        memset((cou_b),0,sizeof(cou_b));
        for(int i=0;i<n;i++){
            scanf("%d",&b[i]);
            cou_b[b[i]]++;
            maxi=max(b[i],maxi);
        }
        two=1;
        while(two<maxi)two=two*2;
        vector<LL> res=multiply();
        scanf("%d",&q);
        while(q--){
            int x;
            scanf("%d",&x);
            if(x<res.size())printf("%lld\n",res[x]);
            else puts("0");
        }
    }
    return 0;
}

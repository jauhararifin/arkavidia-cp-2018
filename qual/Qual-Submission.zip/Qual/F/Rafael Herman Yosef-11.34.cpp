#include<bits/stdc++.h>
using namespace std;

const double pi = acos(-1);

const int N = 1<<20; 
typedef complex<double> C;
typedef long long ll;
string t1,t2;

C A[N],B[N],ANS[N],w[N],temp[N];
ll h_val, h_pow;
ll ans[N];
ll num[N],num2[N];

void FFT(C *P,ll depth,ll inv) // 1 for inverse
{
	if(depth == h_pow) return ;
	ll mv = 1 << depth;
	FFT(P,depth+1,inv);
	FFT(P + mv,depth+1,inv);
	ll num = 1 << (h_pow - depth);
	ll pos = 0;
	ll half = num/2;
	C t1,t2;
	for(int a=0;a<half;a++)
	{
		t1 = P[pos];
		t2 = P[pos + mv];
		if(inv==0) t2 = t2 * w[(a<<depth)];
		else t2 = t2 / w[(a<<depth)];
		temp[a] = t1 + t2;
		temp[a + half] = t1 - t2;
		pos = pos + 2*mv;
	}
	for(int a=0 ; a < num;a++) P[a*mv] = temp[a];
	return ;
}

int main()
{
	int n;
	int mtc;
	scanf("%d",&mtc);
	while(mtc--)
	{
		scanf("%d",&n);
		memset(ans,0,sizeof(ans));
		memset(num,0,sizeof(num));
		memset(num2,0,sizeof(num2));
		int maxx = 0;
		for(int a=0;a<n;a++)
		{
			int x;
			scanf("%d",&x);
			num[x]++;
			maxx = max(maxx,x);
		}
		for(int a=0;a<n;a++){
			int x;
			scanf("%d",&x);
			num2[x]++;
			maxx = max(maxx,x);
		}
		ll len1 = 2*maxx;
		h_val = 1, h_pow = 0;
		while(len1 * 2 > h_val) h_val *=2, h_pow++;
		for(int a=0;a<h_val;a++) w[a] = C(cos(2 * pi * a / h_val) , sin(2 * pi *a / h_val));
		for(int a=0;a<h_val;a++) A[a] = C(num[a],0);
		for(int a=0;a<h_val;a++) B[a] = C(num2[a],0);
		FFT(A,0,0);
		FFT(B,0,0);
		for(int a=0;a<h_val;a++) ANS[a] = A[a] * B[a];
		FFT(ANS,0,1);
		for(int a=0;a<h_val;a++) ans[a] = (ll)round(ANS[a].real() / (1.0 * h_val));
		int m;
		scanf("%d",&m);
		while(m--){
			ll x;
			scanf("%lld",&x);
			if(x > 100000) printf("0\n");
			else printf("%lld\n",ans[x]);
		}
	}
}

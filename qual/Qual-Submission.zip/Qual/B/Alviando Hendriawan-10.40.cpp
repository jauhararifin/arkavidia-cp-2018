#include<stdio.h>
#include <iostream>
long long isi(long long x) {
     long long res[] = {x,1,x+1,0};
     return res[x%4];
}

long long xoor(long long x, long long y) {
     return isi(y)^isi(x-1);
}
using namespace std;
int main(){
	int tc;
	cin >> tc;
	for (int i = 0; i < tc; i++){
		long long n,m;
		cin >> n >> m;
		cout << xoor(n,m)<< endl;
	}	
	
	
	
	
	return 0;
}

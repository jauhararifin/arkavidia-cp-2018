#include<bits/stdc++.h>

using namespace std;
typedef long long ll;
#define mp make_pair
#define pb push_back
#define pob pop_back
#define fi first
#define se second

ll getXOR(ll x){
	ll ret[]={x,1,x+1,0};
	return ret[x%4];
}

ll solve(ll a, ll b){
	return getXOR(b)^getXOR(a-1);
}

int main(){
	int t;
	cin>>t;
	while(t--){
		ll l,r;
		cin>>l>>r;
		cout<<solve(l,r)<<endl;
//		puts("");
	}
	return 0;
}

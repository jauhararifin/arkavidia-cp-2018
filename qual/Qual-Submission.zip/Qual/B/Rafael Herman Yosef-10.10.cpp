#include<stdio.h>
#include<sstream>
#include<iostream>

#include<math.h>
#include<algorithm>
#include<utility>
#include<string.h>
#include<string>
#include<stdlib.h>
#include<assert.h>
#include<time.h>

#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>

#define FI first
#define SE second
#define PB push_back
#define MP make_pair
#define endl '\n'
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

void desperate_optimization(int precision){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(precision);
}

ll calc(ll A){
	if(A%4 == 0) return A;
	if(A%4 == 1) return 1;
	if(A%4 == 3) return 0;
	return A + 1;
}

int main(){
	desperate_optimization(10);
	int ntc;
	cin>>ntc;
	while(ntc--){
		ll A,B;
		cin>>A>>B;
		ll A1 = calc(A-1);
		ll B1 = calc(B);
		cout<<(A1 ^ B1)<<endl;
	}
	return 0;
}


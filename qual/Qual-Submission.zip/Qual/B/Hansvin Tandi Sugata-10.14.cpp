#include<bits/stdc++.h>
#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define pob pop_back
#define pf push_front
#define pof pop_front
#define FOR(i,n) for(int i=0;i<n;i++)
#define REPP(i,l,r,c) for(int i=l;i<=r;i+=c)
#define REP(i,l,r) REPP(i,l,r,1)
#define FORD(i,n) for(int i=n-1;i>=0;i--)
#define REVV(i,l,r,c) for(int i=r;i>=l;i-=c)
#define REV(i,l,r) REVV(i,l,r,1)
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef vector<pii> vii;

const int INF=(int)1e9;
const double EPS=(double)1e-9;
const double PI=(double)acos(-1.0);
const ll MOD=(ll)1e9+7;

int irand(int lo, int hi){
	return (((double)rand())/(RAND_MAX+1.0)) * (hi-lo+1) + lo;
}

string toString(ll x) {
	stringstream ss;
	ss << x;
	return ss.str();
}

ll toNumber(string S) {
	ll ret;
	sscanf(S.c_str(),"%lld",&ret);
	return ret;
}

void syncOff(){
	ios_base::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
}

ll solve(ll x){
	ll tmp = (x&3);
	if(tmp==0) return x;
	else if(tmp==1) return 1;
	else if(tmp==2) return x+1;
	else return 0;
}

int main(){
	int tc;
	scanf("%d",&tc);
	while(tc--){
		ll a,b;
		scanf("%lld %lld",&a,&b);
		printf("%lld\n",solve(a-1)^solve(b));
	}
	return 0;
}


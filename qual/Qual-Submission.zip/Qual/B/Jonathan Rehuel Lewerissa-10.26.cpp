#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

template <typename T>
T G(){
    T res=0;char c;
    bool minus=false;
    while(1){
        c=getchar_unlocked();
        if(c==' '||c=='\n') continue;
        if(c=='-')minus=true;
        else break;
    }res=c-'0';
    while(1){
        c=getchar_unlocked();
        if(c>='0'&& c<='9') res=10*res+c-'0';
        else break;
    }return (minus)? -res : res;
}

ll awal(ll a) {
	int hasil = a%4;
	if(hasil==0)return a;
	else if(hasil == 1)return 1;
	else if(hasil == 2)return a+1;
	else return 0;

}

ll res(ll a, ll b) {
     return awal(a-1) ^ awal(b);
}


int main()
{
	int tc;
	tc = G<int>();
	while(tc--){
		ll a,b;
		a = G<ll>();
		b = G<ll>();
		printf("%lld\n",res(a,b));
	}
	return 0;
}
#include <stdio.h>
#include <iostream>
using namespace std;
long long int pow(int a)
{
    if (a==0)return 1;
    return 2*pow(a-1);
}
int main()
{
    int tc;
    cin>>tc;
    while (tc--)
    {
        long long int l,r;
        long long int res=0;
        long long int tim;
        cin>>l>>r;
        if (l==r)printf ("%lld\n",l);
        else if (r-l==1)printf ("%lld\n",l^r);
        else if (l%2==0)
        {
            res=1;
            tim=r-l-1;
            res^=(tim/2)%2;
            if (tim%2==0)
            {
                printf ("%lld\n",res);
            }
            else printf ("%lld\n",res^r);
        }
        else
        {
            res=l;
            tim=r-l;
            res^=(tim/2)%2;
            if (tim%2==0)
            {
                printf ("%lld\n",res);
            }
            else printf ("%lld\n",res^r);
        }
    }
}

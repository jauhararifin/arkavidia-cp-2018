#include<bits/stdc++.h>
using namespace std;

const int INF = 1e9;
const int MOD = 1e9+7;
#define fi first
#define se second
#define ll long long
typedef pair<int,int> ii;
typedef pair<int,ii> iii;
int dX[]={0,0,-1,1};
int dY[]={-1,1,0,0};

ll f(ll a){
    ll arr[]={a,1,a+1,0};
    return arr[a%4];
}

ll XOR(ll a, ll b){
    return f(b)^f(a-1);
}

int main(){
	ll n;
	scanf("%lld",&n);
	while(n--){
		ll l,r;
		scanf("%lld %lld",&l,&r);
		printf("%lld\n",XOR(l,r));
	}
	return 0;
}

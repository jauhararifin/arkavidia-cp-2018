#include<bits/stdc++.h>
using namespace std;
#define ll long long

int tc;
ll l,r;

ll xo(ll x)
{
	if(x%4==0) return x;
	else if(x%4==1) return 1;
	else if(x%4==2) return x+1;
	else return 0;
}

int main()
{
	scanf("%d",&tc);
	while(tc--)
	{
		scanf("%lld%lld",&l,&r);
		l--;
		l=xo(l);
		r=xo(r);
		printf("%lld\n",l^r);
	}
 	return 0;
}


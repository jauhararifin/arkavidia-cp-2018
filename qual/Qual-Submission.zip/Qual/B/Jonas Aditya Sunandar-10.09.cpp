#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef pair<int,ii> iii;
const int INF=(int)2e9;
const double EPS=(double)1e-9;
const double PI=(double)acos(-1.0);
const ll MOD=(ll)1e9+7;

#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define FOR(i,a,n) for(int i=a;i<n;i++)
#define MAX 100005
#define wa cout<<"wa"<<endl;
#define LEFT 2*node
#define RIGHT 2*node+1
void base(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
}
long long f(long long a) {
     long long res[] = {a,1,a+1,0};
     return res[a%4];
}

long long calc(long long a, long long b) {
     return f(b)^f(a-1);
}

int main(){
//	base();
	int t;
	cin>>t;
	while(t--){
		ll a,b;
		cin>>a>>b;
		cout<<calc(a,b)<<endl;
	}
	return 0;
}



#include <iostream>
#include <cstdio>

#define ll long long

using namespace std;

ll xorsum(ll x){
    if (x % 4 == 0){
        return x;
    }
    else if (x % 4 == 1){
        return 1;
    }
    else if (x % 4 == 2){
        return x + 1;
    }
    else if (x % 4 == 3){
        return 0;
    }

}

int main(){
    int t;
    ll l, r;
    cin >> t;
    while (t--){
        cin >> l >> r;
        cout << (xorsum(l-1) ^ xorsum(r)) << "\n";
    }
    return 0;
}

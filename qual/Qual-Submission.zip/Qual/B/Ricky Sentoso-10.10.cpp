#include<bits/stdc++.h>
using namespace std;
#define LL long long
#define ULL unsigned LL
#define PII pair<int,int>
#define VI vector<int>
#define VPII vector< PII >
#define VVI vector< VI >
#define PB push_back
#define F first
#define S second
const int INF=1e9;
const int MOD=1e9+7;
int t;
LL l,r;
LL f(LL x){
    if(x<0)return 0;
    if(x%4==0)return 1;
    else if(x%4==1){
        return 3ll+(x/4ll)*4ll;
    }
    else if(x%4==2){
        return 0;
    }
    else{
        return 4ll+(x/4ll)*4ll;
    }
}
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%lld %lld",&l,&r);
        l--;
        r--;
        LL le=f(l-1);
        LL ri=f(r);
        printf("%lld\n",le^ri);
    }
    return 0;
}

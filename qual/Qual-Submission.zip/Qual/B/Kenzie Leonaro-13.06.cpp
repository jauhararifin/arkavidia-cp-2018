#include <stdio.h>
long long f(long long a) {
     long long res[] = {a,1,a+1,0};
     return res[a%4];
}

long long getXor(long long a, long long b) {
     return f(b)^f(a-1);
}
int main(){
	long long int T;
	unsigned long long int A,B,C;
	scanf("%lld",&T);
	while(T--){
		scanf("%llu %llu",&A,&B);
		printf("%lld\n",getXor(A,B));
	}
	return 0;
}

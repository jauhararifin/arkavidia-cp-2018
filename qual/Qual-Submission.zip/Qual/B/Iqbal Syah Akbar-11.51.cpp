#include<iostream>
using namespace std;


unsigned long long int f(unsigned long long int a){
    unsigned long long int re[4] = {a,1,a+1,0};
    return re[a%4];
}

int main(){
    unsigned long long int t, a, b;
    cin>>t;
    unsigned long long int res[t], s=t;
    for(;t>0;t--){
        cin>>a>>b;
        res[t-1]=f(b)^f(a-1);
    }
    for(;s>0;s--)if(s>1)cout<<res[s-1]<<endl;
    else cout<<res[s-1];
}

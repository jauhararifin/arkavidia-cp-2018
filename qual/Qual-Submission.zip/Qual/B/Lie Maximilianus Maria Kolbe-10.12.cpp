#include<bits/stdc++.h>
#define fi first
#define se second
#define pb push_back
#define pob pop_back
#define mp make_pair
#define FOR(i,n) for (int i=0;i<n;i++)
#define REP(i,l,r) for (int i=l;i<r;i++)
#define REPS(i,l,r) for (int i=l;i<=r;i++)
#define FORD(i,n) for (int i=n-1;i>=0;i--)
#define REPD(i,l,r) for (int i=r-1;i>=l;i--)
#define REPDS(i,l,r) for (int i=r;i>=l;i--)
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;

const int INF=(int)1E9;
const ll INFLL=(ll)1E15;
const double INFD=1E9;
const ll MOD=(ll)1E9+7;
const double PI=acos(-1);
const double EPS=1E-9;

bool between(int x,int l,int r) {
	return (l<=x && x<=r);
}

string tostring(int x) {
	char dum[20]; sprintf(dum,"%d",x);
	string ret(dum); return ret;
}

ll hitung(ll x) {
	if (x%4==0) return x;
	if (x%4==1) return 1;
	if (x%4==2) return x+1;
	return 0;
}

int main() {
	ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int kasus; cin>>kasus;
	while (kasus--) {
		ll l,r; cin>>l>>r;
		ll ans=hitung(r)^hitung(l-1);
		cout<<ans<<endl;
	}
	return 0;
}

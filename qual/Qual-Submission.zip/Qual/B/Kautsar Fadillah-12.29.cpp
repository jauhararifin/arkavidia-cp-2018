#include <bits/stdc++.h>
using namespace std;

#define FAST_CC ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define fi first
#define se second
#define pb push_back
#define RESET(s, x) memset(s, x, sizeof(s))

typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int, vii > viii;

const double PI = acos(-1.0);
const double EPS = 1e-9;
const int MOD = 1e9 + 7;
const int INF = 1e9;
const long long INFLL = 4e18;
const int dr[] = {-1, 0, 1, 0, -1, 1, 1, -1};
const int dc[] = {0, 1, 0, -1, 1, 1, -1, -1};

long long f(long long a) {
     long long res[] = {a,1,a+1,0};
     return res[a%4];
}

long long getXor(long long a, long long b) {
     return f(b)^f(a-1);
}

int main() {
	FAST_CC
	int t;
	scanf("%d", &t);
	while(t--) {
		long long l, r;
		scanf("%lld %lld", &l, &r);

		printf("%lld\n", getXor(l, r));
	}
	return 0;
}
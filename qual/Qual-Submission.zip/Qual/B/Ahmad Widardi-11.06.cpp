#include<bits/stdc++.h>
#define cincout ios::sync_with_stdio(false)
#define mp make_pair
#define fi first
#define se second
#define pb push_back

using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef map<int, int> mii;

ll t,l,r;
ll ans;
int main(){
	cin >> t;
	
	for(int i=1;i<=t;i++){
		cin >> l >> r;
		if(r%4==0){
			ans=r;
		}else if(r%4==1){
			ans=1;
		}else if(r%4==2){
			ans=r+1;
		}else if(r%4==3){
			ans=0;
		}
		if((l-1)%4==0){
			ans^=(l-1);
		}else if((l-1)%4==1){
			ans^=1;
		}else if((l-1)%4==2){
			ans^=l;
		}else if((l-1)%4==3){
			ans^=0;
		}
		cout << ans <<endl;
	}
}

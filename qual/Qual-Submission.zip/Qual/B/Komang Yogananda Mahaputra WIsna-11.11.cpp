#include <bits/stdc++.h>
using namespace std;
long long pola(long long a){
    long long pat[]={a,1,a+1,0};
    return pat[a%4];
}
int main(){
    int tc;
    scanf("%d",&tc);
    while(tc--){
        long long l,r;
        scanf("%lld %lld",&l,&r);
        long long jwb=pola(r)^pola((l-1));
        printf("%lld\n",jwb);
    }
    return 0;
}
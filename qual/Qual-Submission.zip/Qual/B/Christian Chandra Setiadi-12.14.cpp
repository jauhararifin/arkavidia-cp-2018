#include <iostream>

using namespace std;

int main() {
    int tc;
    long long int l, r;
    cin>>tc;
    for(;tc;tc--){
        cin>>l>>r;
        long long int ans;
        long long int range=r-l;
        if(l%2==1){
            if(range%4==0){
                ans=l;
            }
            else if(range%4==1){
                ans=l^r;
            }
            else if(range%4==2){
                ans=l-1;
            }
            else if(range%4==3){
                ans=(l-1)^r;
            }
        }
        else{
            if(range%4==0){
                ans=r;
            }
            else if(range%4==1){
                ans=1;
            }
            else if(range%4==2){
                ans=r+1;
            }
            else if(range%4==3){
                ans=0;
            }
        }
        
        cout<<ans<<endl;
    }
}

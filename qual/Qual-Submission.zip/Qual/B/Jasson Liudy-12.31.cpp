#include<bits/stdc++.h>
#define INF 1000000000
#define pii pair<int, int>
#define fi first
#define se second
#define pb push_back
#define ll long long
using namespace std;

ll bitlist[70];

ll getbit(ll L, ll R, ll now)
{
	ll b=0;
	b+=(R/now)*(now/2);
	b+=max((ll)0, ((R%now)-((now/2)-1)));
	b-=(L/now)*(now/2);
	b-=max((ll)0, ((L%now)-((now/2)-1)));
	return b;
}

int main()
{
	int tc;
	cin>>tc;
	for(int ntc=0;ntc<tc;ntc++)
	{
		ll l, r;
		cin>>l>>r;
		ll pos=2;
		int c=0;
		while(pos/2 <= r)
		{
			bitlist[c]=getbit(l-1, r, pos);
			pos*=2;
			c++;
		}
		if(l==r)
		{
			cout<<l<<endl;
		}
		else
		{
			ll hasil=0;
			ll now=1;
			for(int a=0;a<c;a++)
			{
//				cout<<bitlist[a]<<endl;
				if(bitlist[a]%2==1)
				{
					hasil+=now;
				}
				now*=2;
			}
			cout<<hasil<<endl;
		}
	}
 	return 0;
}


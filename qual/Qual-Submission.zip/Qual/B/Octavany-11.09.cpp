#include<stdio.h>
#include<math.h>

int main(){
	int t;
	long long int l, r;
	int i;
	long long int j;
	long long int hasil=0;
	long long int hasilL, hasilR;
	
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%lld %lld",&l,&r);
		if((l-1)%4 == 0){
			hasilL = l-1;
		}
		else if((l-1)%4 == 1){
			hasilL = 1;
		}
		else if((l-1)%4 ==2 ){
			hasilL = l;
		}
		else if((l-1)%4 == 3){
			hasilL = 0;
		}
		
		if(r%4 == 0){
			hasilR = r;
		}
		else if(r%4 == 1){
			hasilR = 1;
		}
		else if(r%4 ==2 ){
			hasilR = r+1;
		}
		else if(r%4 == 3){
			hasilR = 0;
		}
		
	
		if(l == 1){
			hasil = hasilR;
		}
		else{
			hasil = (hasilL ^ hasilR);	
		}
//		
//		hasil = 0;
//		for(j = l;j<=r;j++){
//			hasil ^= j;
//		}
		printf("%lld\n",hasil);
	}
	return 0;
}

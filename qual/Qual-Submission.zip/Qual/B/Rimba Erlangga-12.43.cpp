#include <bits/stdc++.h>
#define ll long long
#define maxi 1000000000
using namespace std;

int T;
ll L, R, ans;

ll a(ll R) {
	if(R%4 == 0) return R;
	else if(R%4 == 3) return 0;
	else if(R%4 == 2) return R+1;
	else return 1;
}

int main() {
	cin >> T;
	while(T--) {
		cin >> L >> R;
		cout << (a(R) xor a(L-1)) << endl;
	}
	
	return 0;
}

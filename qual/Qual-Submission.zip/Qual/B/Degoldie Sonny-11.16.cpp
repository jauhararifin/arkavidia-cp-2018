#include <bits/stdc++.h>
using namespace std;

long long powers[65];

long long getVal(long long x){
	x++;
	long long ret = 0;
	int now = 1;
	while(now <= 60){
		long long tmp = powers[now];
		long long tmp2 = tmp/2;
		long long aha = ((x/tmp)*(tmp2) + max(0LL, ((x%tmp) - tmp2)) ) & 1;

		if(aha) ret|= tmp2;

		now++;
	}
	return ret;
}

int main(){
	powers[0] = 1;
	for (int i = 1; i <= 60; i++){
		powers[i] = powers[i-1]*2;
	}

	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++){
		long long a, b;
		scanf("%lld%lld", &a, &b);

		printf("%lld\n", getVal(a-1)^getVal(b));
	}
}
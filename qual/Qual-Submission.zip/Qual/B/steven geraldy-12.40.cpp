#include <iostream>
using namespace std;
int main(){
	int a;
	cin>>a;
	for(int j=0;j<a;j++){
		long long int b,c;
		cin>>b>>c;
		long long e=b%4;
		long long d=c%4;
		long long g=0;
		long long int f=0;
		long long x=0,y=0;
		if(b%4==0){
			x=b^b+1;
			y=x^x+1^x+2;
				
		}
		if(b%4==1){
			x=b;
			y=x^x+1^x+2;
		}
		if(b%4==2){
			y=b^b+1;
			x=y^y+1^y+2;
		}
		if(b%4==3){
			y=b;
			x=y^y+1^y+2;
		}
		if(d==0){
			f=y^c;
			cout<<f<<endl;
		}else if(d==1){
			cout<<x<<endl;
			
			
		}else if(d==2){
			f=x^c;
			cout<<f<<endl;
			
		}else if(d==3){
			cout<<y<<endl;
			
		}
	}	
	}

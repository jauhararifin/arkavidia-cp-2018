#include <bits/stdc++.h>
using namespace std;
long long cal(long long l, long long r) {
    return l * (l & 1LL) ^ r * !(r & 1LL) ^ !!(((l ^ r) + 1LL) & 2LL);
}
int main()
{
    int t;
    cin>>t;
    long long a,b;
    while(t--)
    {
        cin>>a>>b;
        cout<<cal(a,b)<<endl;
    }
    return 0;
}

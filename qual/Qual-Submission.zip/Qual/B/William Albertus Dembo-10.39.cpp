#include<bits/stdc++.h>

using namespace std;

long long f(long long x) {
    long long ans[4];
    ans[0] = x;
    ans[1] = 1;
    ans[2] = x+1;
    ans[3] = 0;
    return ans[x%4];
}

long long ans(long long a, long long b) {
    return f(b) ^ f(a-1);
}

int main() {
    int tt;
    scanf("%d", &tt);
    while(tt--) {
        long long a,b;
        scanf("%lld%lld", &a, &b);
        printf("%lld\n", ans(a,b));
    }
}
#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

typedef vector<int> vi;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef vector<pii> vii;

#define mp make_pair
#define fi first
#define se second

#define pb push_back
#define pob pop_back
#define pf push_front
#define pof pop_front

#define FOR(i,n) for(int i=0;i<n;i++)
#define REPP(i,l,r,c) for(int i=l;i<=r;i+=c)
#define REP(i,l,r) REPP(i,l,r,1)

#define FORD(i,n) for(int i=n-1;i>=0;i--)
#define REVV(i,l,r,c) for(int i=max(l,r),_m=min(l,r);i>=_m;i-=c)
#define REV(i,l,r) REVV(i,l,r,1)

ll oddcnt(ll l, ll r){
//	cout<<"odc"<<l<<' '<<r<<' '<<(r-l)/2 +1<<endl;
	if(l>r)return 0;
	if(l%2==0)l++;
	if(r%2==0)r--;
	return (r-l)/2 +1;
}

ll comp(ll n){
	int tmp=n%4;
	if(tmp==0)return n;
	if(tmp==1)return 1;
	if(tmp==2)return n+1;
	return 0;
}

int main(){
	int tc; cin>>tc;
	while(tc--){
		ll l, r;
		cin>>l>>r;
		
		cout<<(comp(r)^comp(l-1))<<endl;
	}
	return 0;
}

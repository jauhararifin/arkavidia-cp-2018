#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> ii;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef pair<double, double> pdd;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<pii> vii;

#define newline '\n';
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define FAST_IO  ios_base::sync_with_stdio(false)

const int PI = acos(-1.0);
const int MOD = 1e9 + 7;

ll power(ll a, int b) {
	if (b == 0) return 1LL;
	if (b == 1) return a % MOD;
	ll ret = power(a, b / 2) % MOD;
	ret = (ret * ret) % MOD;
	if (b & 1) ret = (ret * a) % MOD;
	return ret;
}

void tests() {
	assert(power(2, 10) == 1024);
}

ull x(ull a) {
	if (a % 4ULL == 0) return a;
	if (a % 4ULL == 1) return (ull)1;
	if (a % 4ULL == 2) return a+1;
	return (ull)0;
}

void solve() {
	ull l, r;
	cin >> l >> r;
	cout << (x(r) ^ x(l-1))  << newline;
}

int main() {
	FAST_IO;

	int tc;
	cin >> tc;
	while(tc--) {
		solve();
	}

	// tests();
	return 0;
}

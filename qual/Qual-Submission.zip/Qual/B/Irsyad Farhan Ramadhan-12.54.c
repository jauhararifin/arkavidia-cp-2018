#include<stdio.h>

int main(){
	unsigned long long a,b,i,curr;
	int T;
	scanf("%d",&T);
	while(T--){
		scanf("%llu %llu",&a,&b);
		if(b-a<4){
			curr = a;
			i = a+1;
			while(i <= b){
				curr = curr ^ i;
				i++;
			}
		} else {
			curr = a;
			i = a+1;
			while(i%4!=0){
				curr = curr ^ i;
				i++;
			}
			curr = curr ^ b;
			i = b-1;
			while((i+1)%4!=0){
				curr = curr ^ i;
				i--;
			}
		}
		printf("%llu\n",curr);
	}
	return 0;
}

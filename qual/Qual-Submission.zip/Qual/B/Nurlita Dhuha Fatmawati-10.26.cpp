#include <stdio.h>
#include <string>
#include <string.h>
#include <iostream>
#include <algorithm>
#include <stdlib.h>
#include <queue>
#include <vector>
#include <stack>
#include <limits.h>
#include <map>
using namespace std;
#define mp make_pair
#define fi first
#define se second
#define pb push_back
#define ll long long int
#define ull unsigned long long int

ll xors(ll n){
    if(n%4==0){
        return n;
    }
    else if(n%4==1) return 1;
    else if(n%4==2) return n+1;
    else return 0;
}
int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        ll l,r;
        scanf("%lld %lld",&l,&r);
        ll ans=xors(r)^xors(l-1);
        printf("%lld\n",ans);
    }
    return 0;
}

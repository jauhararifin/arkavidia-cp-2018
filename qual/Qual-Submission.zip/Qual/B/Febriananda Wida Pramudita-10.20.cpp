#include<bits/stdc++.h>
using namespace std;

#define ll long long

int main() {
	int tes;
	ll has, L, R, range;
	scanf("%d", &tes);
	while(tes--) {
		has = 0;
		scanf("%lld %lld", &L, &R);
		if(R - L <= (ll)1) {
			for(ll x = L; x <= R; x++) {
				has ^= x;
			}
		}
		else {
			if(L & (ll)1) {
				has ^= L;
				L++;
			}
			if(!(R & (ll)1)) {
				has ^= R;
				R--;
			}
			range = (R - L + (ll)1) / 2;
			has ^= (range & (ll)1);
		}
		printf("%lld\n", has);
	}
}
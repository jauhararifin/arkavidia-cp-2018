#include <stdio.h>

long int cek(long long int x){
	if(x%4==0){
		return x;
	}else if(x%4==1){
		return  1;
	}else if(x%4==2){
		return x+1;
	}else{
		return 0;
	}
}

int main(){
	long int tc,i,ki,ka;
	long long int l,r;
	
	scanf("%ld",&tc);
	for(i=0;i<tc;i++){
		scanf("%lld %lld",&l,&r);
		ki = cek(l-1);
		ka = cek(r);
		printf("%lld\n",ka^ki);
	}
}

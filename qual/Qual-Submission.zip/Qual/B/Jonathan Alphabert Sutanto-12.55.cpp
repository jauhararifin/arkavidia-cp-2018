#include<stdio.h>

int main(){
	int T;
	scanf("%d", &T);
	while(T--){
		long long int a,b;
		scanf("%lld %lld", &a, &b);
		long long res;
		if(a%2==1){
			if(b%2==1){
				res=(b-a)/2%2;
				res^=a;
			}
			else{
				res=(b-a-1)/2%2;
				res^=a^b;
			}
		}
		else{
			if(b%2==1){
				res=(b-a+1)/2%2;
			}
			else{
				res=(b-a)/2%2;
				res^=b;
			}
		}
		printf("%lld\n", res);
	}
}

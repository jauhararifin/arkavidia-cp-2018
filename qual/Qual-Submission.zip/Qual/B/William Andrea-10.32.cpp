#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
#define pb push_back
#define mp make_pair
#define pii pair<int, int>
#define ff first
#define ss second
#define nl '\n'
#define sp ' '
#define cnl cout<<nl
#define nrep(i,a,b,c) for (int i=a; i<=b; i++)
#define rep(i,a,b) for (int i=a; i<=b; i++)
#define repp(i,a,b) for (int i=a; i>=b; i--)
#define l(s) int len=s.size()

ll f(ll a) {
     ll res[] = {a,1,a+1,0};
     return res[a%4];
}

ll getXor(ll a, ll b) {
     return f(b)^f(a-1);
}

int main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int tc;
    ull l, r;
    cin>>tc;
    while (tc--){
        cin>>l>>r;
        cout<<getXor(l, r)<<nl;

    }
    return 0;
}

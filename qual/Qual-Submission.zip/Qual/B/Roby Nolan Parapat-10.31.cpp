#include <bits/stdc++.h>
#define MAX 1000000000

typedef unsigned long long ll;
using namespace std;

ll Xor(ll a, ll b) {
 return a * (a & 1) ^ b * !(b & 1) ^ !!(((a ^ b) + 1) & 2);
}

int main(){
	int t;
	ll l,r;
	cin >> t;
	while(t--){
		cin >> l >> r;
		cout << Xor(l,r) << endl;
	}
	return 0;	
}



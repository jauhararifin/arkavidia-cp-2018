#include<bits/stdc++.h>
using namespace std;


int main() 
{
	int tc=0;
	cin>>tc;
	
	
	while(tc--)
	{
	    
	    long long int a=0,n=0;
	    cin>>a>>n;
	    
	    long long int temp=0;
	    
	    temp=n-a;
	    
	    long long int answer=0;
	    if(a%2==1)
	    {
	        if(temp%4==0)
    	    {
    	        answer=a;
    	    }
    	   
    	    
    	    else if(temp%4==1)
    	    {
    	        answer=a^n;
    	    }
    	    
    	    else if(temp%4==2)
    	    {
    	        answer=a-1;
    	    }
    	    
    	    else if(temp%4==3)
    	    {
    	        answer=(a-1)^n;
    	    }
	    }
	    else
	    {
	        if(temp%4==0)
    	    {
    	        answer=n;
    	    }
    	   
    	    
    	    else if(temp%4==1)
    	    {
    	        answer=1;
    	    }
    	    
    	    else if(temp%4==2)
    	    {
    	        answer=n+1;
    	    }
    	    
    	    else if(temp%4==3)
    	    {
    	        answer=0;
    	    }
	    }
	    
	    
	    cout<<answer<<endl;
	    
	}
	
	
}


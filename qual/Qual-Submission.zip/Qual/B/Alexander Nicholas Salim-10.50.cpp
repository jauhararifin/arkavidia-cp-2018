#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<string> vs;
#define pb(x) push_back(x)
#define PI 3.14159
#define INF 1e9+7

int gcd(int a, int b){
	if(b == 0) return a;
	return (b, a%b);
}

int lcm(int a, int b){
	return (a * (b / gcd(a, b)));
}

ull f(ull a) {
    ull res[] = {a,1,a+1,0};
    return res[a%4];
}
	
ull getXor(ull a, ull b) {
    return f(b)^f(a-1);
}

int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	ull t, l, r;
	
	cin >> t;
	for(ull tt = 0; tt < t; tt++){
		cin >> l >> r;
		cout << getXor(l, r) << endl;
	}

	return 0;
}


/* ====================================================
Program 		: TeksAlay_ahmadajinaufalali.c
Deskripsi		: Membuat teks alay
Author 			: ahmadajinaufalali
Versi/Tanggal	: 1.00 / 1 Nov 2017
Compiler		: Dev C++
============================================================ */
#include <stdio.h>
#include <string.h> //mencegah warning akibat perintah strlen(teks);

unsigned long long xor(unsigned long long n );

int main()
{
/*DEKLARASI & INISIALISASI */
	long t; 
	unsigned long long a, b,temp;
	int i = 0;

	scanf("%ld", &t);
	i = 0;
	while(i < t)
	{
		scanf("%llu %llu", &a, &b);
		b = xor(b);


		if (a == 1)
		{
			a = 0;
		} else
		{
			a--;
			a = xor(a);

		}
		
		printf("%llu\n", a ^ b);

	i++;
	}

return 0;
}

unsigned long long xor(unsigned long long n)
{
	switch(n%4)
		{
			case 0 : return n; 
			case 1 : return 1;
			case 2 : return n + 1;
			case 3 : return 0;
		}
} 
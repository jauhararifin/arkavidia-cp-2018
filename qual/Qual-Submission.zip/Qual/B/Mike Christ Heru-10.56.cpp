#include<bits/stdc++.h>

using namespace std;

long long o(long long a){
	if(a%4==1)return 1;
	else if(a%4==2)return a+1;
	else if(a%4==3)return 0;
	else return a;
}

long long oo(long long a,long long b){
	return o(b)^o(a-1);
}


int main(){
	long long a,b;
	int in;
	scanf("%d",&in);
	for(int i=1;i<=in;i++){
		scanf("%lld %lld",&a,&b);
		printf("%lld\n",oo(a,b));
	}
	return 0;
}

#include <bits/stdc++.h>
using namespace std;

bool IsPrime(int x)
{
	if (x==1) return false;
	int akar=(int)sqrt(x);
	for (int i=2;i<=akar;i++)
	{
		if (x%i==0) return false;
	}
	return true;
}

typedef long long ll;

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
//	freopen("input.txt","r",stdin);
	ll t;
	cin>>t;
	while (t--)
	{
		ll a,b;
		cin>>a>>b;
		ll awal;
		if (b%4==0)
		 awal=b;
		else
		 if (b%4==1)
		  awal=1;
		  else
		   if (b%4==2)
		    awal=b+1;
		   else
		    if (b%4==3)
		     awal=0;
		if (a==1)
		 cout<<awal<<"\n";
		else
		 {
		 	ll prefix=a-1;
		 	ll kurang;
		 	if (prefix%4==0)
		 	 kurang=prefix;
		 	else
		 	 if (prefix%4==1)
		 	  kurang=1;
		 	 else
		 	  if (prefix%4==2)
		 	   kurang=prefix+1;
		 	  else
		 	   if (prefix%4==3)
		 	    kurang=0;
		 	ll ans=kurang^awal;
		 	cout<<ans<<"\n";
		 }
	}
}

#include<stdio.h>
#include<string.h>

#include<iostream>
#include<string>
#include<algorithm>
#include<map>

using namespace std;

long long func(long long a) {
     long long temp[] = {a,1,a+1,0};
     return temp[a%4];
}

long long XOR(long long a, long long b) {
     return func(b)^func(a-1);
}

int main()
{
	long long l,r,print;
	int t;
	
	cin>>t;
	while(t--)
	{
		scanf("%lld %lld",&l,&r);
		print = XOR(l,r);
		printf("%lld\n",print);
	}
	
	return 0;
}

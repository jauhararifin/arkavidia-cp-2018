#include<bits/stdc++.h>
using namespace std;

long long f(long long a)
{
	long long res[4] = {a, 1, a+1, 0};
     return res[a%4];
}
     

long long getXor(long long a,long long  b)
{
	return f(b) ^ f(a-1);
}
     
//long long gen_nums(long long start, long long length)
// {
//    long long l = length;
//    long long ans = 0;
//    while (l>0)
//    {
//	    ans^= getXor(start,start+l-1);
//	        start = start + length;
//	        l = l - 1	;
//	}
//        
//    return ans	;
// }
//    

int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		long long ki,ka;
		scanf("%lld%lld",&ki,&ka);
		printf("%lld\n",getXor(ki,ka));
	}
	
return 0;
}


#include <stdio.h>

long long int solve(long long int a, long long int b){
	if(b%4 == 0) return b;
	if(b%4 == 1) return 1;
	if(b%4 == 2) return b+1;
	if(b%4 == 3) return 0;
}

int main(){
	int tc;
	long long int a, b;
	long long int res1, res2;
	scanf("%d", &tc);
	for(int i = 0; i<tc; i++){
		scanf("%lld %lld", &a, &b);
		res1 = solve(1, a-1);
		res2 = solve(1, b);
		printf("%lld\n", res2 ^ res1);
	}
	return 0;
}

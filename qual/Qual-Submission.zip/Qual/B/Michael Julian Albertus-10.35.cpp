#include<stdio.h>

long long int xori(long long int a){
    if(a%4==0) return a;
    else if(a%4==1) return 1;
    else if(a%4==2) return a+1;
    else if(a%4==3) return 0;
}

int main(){
    int tc;
    long long int a,b;
    scanf("%d",&tc);
    while(tc--){
        scanf("%lld%lld",&a,&b);
        printf("%lld\n",xori(b)^xori(a-1));
    }
    return 0;
}
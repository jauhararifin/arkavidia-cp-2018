#include<bits/stdc++.h>
#define loop(a,b,c) for(int a=b;a<c;a++)
#define fi first
#define se second
#define mp make_pair
#define all(v) v.begin(),v.end()
#define pb push_back
#define sz(v) v.size()
using namespace std;
typedef long long LL;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef pair<int,ii> iii;
typedef vector<iii> viii;
const double PI=2*acos(0);
const LL MOD=1000*1000*1000+7;
//templates ends here

int main(){
    int T;
    //ios_base::sync_with_stdio(false);
    //cin.tie(NULL);
    cin>>T;
    while(T--){
        LL a,b,kiri,kanan;
        cin>>a>>b;
        if(a==b){
            cout<<a<<"\n";
            continue;
        }
        if(a==1){
            LL re=b%4;
            if(re==0)cout<<b<<"\n";
            else if(re==1)cout<<"1\n";
            else if(re==2)cout<<b+1<<"\n";
            else cout<<"0\n";
        } else {
            LL re=b%4;
            if(re==0)kanan=b;
            else if(re==1)kanan=1;
            else if(re==2)kanan=b+1;
            else kanan=0;
            re=(a-1)%4;
            if(re==0)kiri=a-1;
            else if(re==1)kiri=1;
            else if(re==2)kiri=a;
            else kiri=0;
            cout<<(kiri^kanan)<<"\n";
        }
    }
}

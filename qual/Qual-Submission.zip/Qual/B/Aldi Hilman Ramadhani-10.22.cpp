#include <bits/stdc++.h>
using namespace std;

long long n,i,l,r,ans,t;
long long cnt(long long x){
  long long apa = x%4;
  if (apa == 0) return x^0;
  else if (apa == 1) return 1^0;
  else if (apa == 2) return (x+1)^0;
  else return 0^0;
}
int main(){
  cin >> t;
  while(t--){
    cin >> l >> r;
    // cout << cnt(l) << " " << cnt(r) << endl;
    ans = cnt(l-1)^cnt(r);
    cout << ans << endl;
  }
}

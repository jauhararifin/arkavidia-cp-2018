#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define MOD 1000000007
#define fi first
#define se second

ll modexp(ll a, ll b, ll m){
    ll res = 1;
    for(; b; b >>= 1, a = (a*a)%m)
        if(b&1) res = (res*a)%m;
    return res%m;
}

int main(){
	int t;
	ll a, b;
	scanf("%d", &t);
	while(t--){
		scanf("%lld%lld", &a, &b);
		ll temp1, temp2;

		if(b%4 == 0) temp2 = b;
		else if(b%4 == 1) temp2 = 1;
		else if(b%4 == 2) temp2 = b+1;
		else if(b%4 == 3) temp2 = 0;

		if((a-1)%4 == 0) temp1 = a-1;
		else if((a-1)%4 == 1) temp1 = 1;
		else if((a-1)%4 == 2) temp1 = a;
		else if((a-1)%4 == 3) temp1 = 0;

		ll ans = temp1^temp2;

		printf("%lld\n", ans);
	}
	return 0;
}

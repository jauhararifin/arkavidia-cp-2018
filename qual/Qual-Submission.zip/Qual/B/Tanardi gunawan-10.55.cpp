#include<stdio.h>
#include<math.h>
#include<string.h>
#include<ctype.h>

long long f(long long n)
{
    if(n%4 == 0)
    {
    	return n;
	}
	else
	if(n%4 == 1)
	{
		return 1;
	}
	else
	if(n%4 == 2)
	{
		return n+1;
	}
	else
	if(n%4 == 3)
	{
		return 0;
	}
}

int main()
{
	long long a ,b ,c,d,e,g,j,t;
		long long arr[210000];
			scanf("%lld",&t);
				for(b =1; b<= t; b++)
				{
					scanf("%lld %lld",&a,&c);
					long long hasil = f(c) ^ f(a-1);
					printf("%lld\n",hasil);
					
				}
}

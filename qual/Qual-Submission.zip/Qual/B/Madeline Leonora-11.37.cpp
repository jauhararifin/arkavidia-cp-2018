#include <iostream>
#include <bits/stdc++.h>
using namespace std;
 
long long int f(long long a){
     long long int res[] = {a,1,a+1,0};
     return res[a%4];
}

long long int get(long long a, long long b) {
     return f(b)^f(a-1);
}
 
int main()
{
    long long int tc;
	cin>>tc;
	while(tc--){
		long long int l,r, res;
		cin>>l>>r;
    cout << get(l,r)<<endl;
	}
    return 0;
}

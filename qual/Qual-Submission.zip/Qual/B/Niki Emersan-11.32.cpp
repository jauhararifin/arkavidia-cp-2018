#include<stdio.h>

long long int mode(long long int bil) {
     long long d[5] = {bil,1,bil+1,0};
     return d[bil%4];
}

long long int fXor(long long int a, long long int b) {
     return mode(b)^mode(a-1);
}

int main() {
    int tc;
    long long int l, r;

    scanf("%d", &tc);
    for(int t=0;t<tc;t++) {
        scanf("%lld %lld", &l, &r);
        printf("%lld\n", fXor(l, r));
    }

    return 0;
}

#include<bits/stdc++.h>

using namespace std;

long long int f(long long int a) {
     long long res[] = {a,1,a+1,0};
     return res[a%4];
}

long long int getXor(long long int a, long long int b) {
     return f(b)^f(a-1);
}

int main (){
	
	int T;
	long long int l, r;
	long long int x;
	
	cin>>T;
	while(T--){
		cin>>l>>r;
		x=getXor(l,r);
		printf("%lld\n", x);
	}
	
	return 0;
}

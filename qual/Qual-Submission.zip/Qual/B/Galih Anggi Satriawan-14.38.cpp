#include <bits/stdc++.h>

using namespace std;

#define sf scanf
#define pf printf


int main(){
 int t;
 unsigned long long n,l,r,i,rl,hasil;
 cin>>t;
 while(t--){
    cin>>l>>r;
    //cout<<(l^r)<<endl;
    hasil=0;
    if(r-l<3){
        hasil = l;
        for(i=l+1;i<=r;i++){
            hasil = hasil^i;
        }
    //999999999999999999 1000000000000000000
    }else{
        if((l%2==0)){
                rl = r-l;
                if(r%2==0){
                    if((rl/2)%2==0){
                        hasil = r;
                    }else{
                        hasil = r+1;
                    }
                }else{
                  if(((rl+1)/2)%2==0){
                        hasil = 0;
                    }else{
                        hasil = 1;
                    }
                }
        }else{
            rl = r-l;
            if(r%2==0){
                if(((rl-1)/2)%2==0){
                    //cout<<hasil<<" "<<l<<r<<" "<<(l^r)<<endl;
                    hasil = l^r;
                    //cout<<"h"<<endl;
                }else{
                    hasil = l^r^1;
                }
            }else{
                  if((rl/2)%2==0){
                        hasil = l;
                    }else{
                        hasil = l^1;
                    }
                }
        }
    }
    cout<<hasil<<endl;
 }
 return 0;
}

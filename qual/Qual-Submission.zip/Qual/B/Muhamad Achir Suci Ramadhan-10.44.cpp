#include <iostream>

#define lo long long
using namespace std;

lo t,n,l,r;
int main()
{
	
	cin>>t;
	while(t--)
	{
		cin>>l>>r;
		if (l%2==0 && r%2==1)
		{
			lo sum=r-l+1;
			if (sum%4==2) cout<<1<<endl;
			else cout<<0<<endl;
		}
		else if (l%2 == 1 && r%2 ==1)
		{
			lo sum=r-l;
			if (sum%4==2) cout<<(1LL^l) <<endl;
			else cout<<l<<endl;
		}
		else if (l%2 == 0 && r%2 ==0)
		{
			lo sum=r-l;
			if (sum%4==2) cout<<(1LL^r) <<endl;
			else cout<<r<<endl;
		}
		else
		{ 
			lo sum=r-l-1;
			if (sum%4==2) cout<<((1LL^r)^l) <<endl;
			else cout<<(r^l)<<endl;
		}
	}
	
	return 0;
}

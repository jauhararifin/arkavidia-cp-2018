#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

int main()
{
	unsigned long long int l,r,x,y;
	int t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%llu %llu",&l,&r);		
		x = l-1;
		y = x%4;
		if(x == 0)
		l = x;
		if(y  == 0)
		l = x;
		else if(y  == 1)
		l = y;
		else if(y  == 2)
		l = x+1;
		else if(y  == 3)
		l = 0;
		
		x = r;
		y = x%4;
		if(x == 0)
		r = x;
		if(y  == 0)
		r = x;
		else if(y  == 1)
		r = y;
		else if(y  == 2)
		r = x+1;
		else if(y  == 3)
		r = 0;
		printf("%llu\n",l^r);
	}
	return 0;
}

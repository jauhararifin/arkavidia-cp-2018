#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

ll f(ll x) {
	if (x%4==0) return x;
	else if (x%4==1) return 1;
	else if (x%4==2) return x+1;
	else if (x%4==3) return 0;	
}

int main() {
	int tc;
	scanf("%d", &tc);
	ll l, r;
	while (tc--) {
		scanf("%lld %lld", &l, &r);
		ll ans = f(l-1) ^ f(r);
		printf("%lld\n", ans);
	}
	
	return 0;	
}

/* 
 * Work Over Your Laziness
 * 
 */

#include<iostream>
#include<stdio.h>
#include<vector>
#include<utility>
#include<map>
#include<algorithm>
#include<string>
#include<string.h>
#include<queue>
#include<stack>
#include<cmath>
#include<set>
#include<sstream>

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define MOD 1000000007
#define PHI 2.0*acos(0.0)
#define FOR(i,j) for (int (i) = 0;(i) < (j);(i)++)
#define FORU(i,j,k) for (int (i) = (j);(i) <= (k);(i)++)
#define FORD(i,j,k) for (int (i) = (j);(i) >= (k);(i)--)

using namespace std;

typedef long long ll;
typedef pair<int,int> ii;
typedef pair<ii,int> iii;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<ii> vii;

inline void out(int a){
	printf("%d\n",a);
}
inline void out(int a,int b){
	printf("%d %d\n",a,b);
}
inline void outf(double a){
	printf("%3.lf\n",a);
}
inline void outf(double a,double b){
	printf("%3.lf %3.lf\n",a,b);
}
inline void base(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
}

ll ar[64];
ll pr[64];

ll odd(ll x){
	if(x%2==1)return x/2 + 1;
	return x/2;
}

ll get(ll x,int idx){
	if(!(x&ar[idx]))return 0;
	ll inv = ~x;
	inv &= pr[idx-1];
	return ar[idx]-inv;
}

int main(){
	base();
	ar[0]=pr[0]=1;
	for(int i = 1;i<64;i++)ar[i]=2LL*ar[i-1],pr[i]=pr[i-1]+ar[i];
	int t;cin>>t;
	while(t--){
		ll l,r;cin>>l>>r;
		ll ans = (odd(r)-odd(l-1))%2;
		for(int i = 1;i<63;i++){
			ll cnt = get(r,i)-get(l-1,i);
			/*if(l&ar[i]){
				ll inv = ~l;
				inv &= l; inv &= pr[i];
				inv++;
				cnt+=inv;
				l+=inv-1;
			}
			if(l!=r && r&ar[i]){
				ll inv = ~r;
				inv ^= r; inv^= pr[i];
				inv = ar[i+1]-inv;
				cnt+=inv;
			}
			*/
			//cout<<i << "-->"<<cnt<<endl;
			if(cnt%2!=0)ans += ar[i];
		}
		cout<<ans<<endl;
	} 
	return 0;
}


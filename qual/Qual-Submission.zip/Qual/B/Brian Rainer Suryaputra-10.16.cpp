#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
ll xxor(ll n){
	switch(n&3){
		case 0: return n;
		case 1: return 1;
		case 2: return n+1;
		case 3: return 0;
	}
}

int main(){
	ll n,a,b;
	cin>>n;
	while(n--){
		cin>>a>>b;
		ll c=xxor(a-1)^xxor(b);
		cout<<c<<endl;
	}
	return 0;
}

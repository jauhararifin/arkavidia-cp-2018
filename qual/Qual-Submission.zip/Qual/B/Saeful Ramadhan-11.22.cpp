#include <bits/stdc++.h>
#define mod 1000000007
using namespace std;
unsigned long long l,r,t,ans,ans1,l1,r1;
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>t;
    for (int i=1; i<=t; i++){
        cin>>l>>r;
        ans1=ans=0;
        l1=r1=0;
        if (l>=7) l1 =3 + ((l-3)/4-1)*4;
        for (long long j=l1+1; j<=l-1; j++) ans1^=j;
        if (r>=7) r1 =3 +((r-3)/4-1)*4;
        for (long long j=r1+1; j<=r; j++) ans^=j;
            //cout<<l1<<" "<<r1<<endl;
        cout<<(ans1^ans)<<"\n";
    }    
}
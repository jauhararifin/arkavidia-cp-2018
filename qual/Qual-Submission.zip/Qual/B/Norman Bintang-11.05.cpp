#include <bits/stdc++.h>
using namespace std;

long long f(long long x) {
    long long now = 1, ret = 0, y = x;
    while (now <= x) {
        now <<= 1LL;
    }

    while (now > 0) {
        long long tmp = x % now;
        // printf("tmp, x, now %lld %lld %lld\n", tmp, x, now);
        if ((tmp >= now / 2LL) && (tmp % 2 == 0)){
            // printf("masuk\n");
            ret |= (now >> 1);
        }
        now >>= 1;
    }

    if (x % 4 == 1 || x % 4 == 2)
        ret++;

    return ret;
}

// long long f(long long x) {
//     long long y = x;
//     long long ret = 0, now = 2;
//     while (now <= x) {
//         if ((x % now == 1 && ((x / now) % 2 == 0)) || 
//     }
// }

int main() {
    int TC;
    scanf("%d", &TC);
    while (TC--) {
        long long l, r;
        scanf("%lld %lld", &l, &r);
        // printf("%lld\n", f(r));
        printf("%lld\n", f(r) ^ f(l-1));
    }
}
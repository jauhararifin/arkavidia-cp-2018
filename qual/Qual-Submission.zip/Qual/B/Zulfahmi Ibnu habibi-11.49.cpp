// Bismillahirohmanirohiim

#include<bits/stdc++.h>
using namespace std;

#define nl "\n"
#define PB push_back
#define SZ size()
#define ios ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL)
#define MP make_pair
#define LEN length()

long long unsigned ubah(long long unsigned x)
{
    long long unsigned temp ;
    if(x%4==0) temp=x;
        else if((x-1)%4==0) temp=1;
        else if((x+1)%4==0) temp=0;
        else temp=((x/4)*4)+3;
    return temp ;
}

int main()
{
    ios;
    long long unsigned t,x,y ;
    cin >> t ;
    while(t--)
    {
        cin >> x >> y ;
//        long long unsigned temp1 = ubah(x);
        long long unsigned temp2 = ubah(y);
        if(x==y)
        {
            cout << x << endl ;
        }
        else if(x%4==0 || x==1)
        {
            cout << temp2 << endl ;
        }
        else if ((x-1)%4==0)
        {
            long long unsigned aw=y-x;
            temp2 = (x^temp2) ;
            if(aw%4==3 or aw%4==2)
            {
                cout << temp2-1 << endl ;
            }
            else
            {
                cout << temp2+1 << endl ;
            }
        }
        else if((x+1)%4==0)
        {
            cout << (x^temp2) << endl ;
        }
        else
        {
            long long unsigned aw=y-x;
            if(aw%4==3 or aw%4==0)
            {
                cout << temp2-1 << endl ;
            }
            else
            {
                cout << temp2+1 << endl ;
            }
        }
    }
}

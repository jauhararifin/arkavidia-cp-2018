/* 
 * Work Over Your Laziness
 * 
 */

#include<iostream>
#include<stdio.h>
#include<vector>
#include<utility>
#include<map>
#include<algorithm>
#include<string>
#include<string.h>
#include<queue>
#include<stack>
#include<cmath>
#include<set>
#include<sstream>

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define MOD 1000000007
#define PHI 2.0*acos(0.0)
#define FOR(i,j) for (int (i) = 0;(i) < (j);(i)++)
#define FORU(i,j,k) for (int (i) = (j);(i) <= (k);(i)++)
#define FORD(i,j,k) for (int (i) = (j);(i) >= (k);(i)--)

using namespace std;

typedef long long ll;
typedef pair<int,int> ii;
typedef pair<ii,int> iii;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<ii> vii;

inline void out(int a){
	printf("%d\n",a);
}
inline void out(int a,int b){
	printf("%d %d\n",a,b);
}
inline void outf(double a){
	printf("%3.lf\n",a);
}
inline void outf(double a,double b){
	printf("%3.lf %3.lf\n",a,b);
}
inline void base(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
}

ll cnt[500005];
ll pre[500005];
ll kdr[500005];
ll dp[200005];

int main(){
	base();
	int t;cin>>t;
	while(t--){
		memset(cnt,0,sizeof cnt);
		memset(pre,0,sizeof pre);
		memset(kdr,0,sizeof kdr);
		memset(dp,-1,sizeof dp);
		ll n,q;cin>>n>>q;
		ll mx = 0;
		FOR(i,n){
			ll a;cin>>a;
			cnt[a]++;
			pre[a]+=a;
			kdr[a]+=a*a;
			mx = max(mx,a);
		}
		
		dp[1]=0;
		FORU(i,1,500000)cnt[i]+=cnt[i-1],pre[i]+=pre[i-1],kdr[i]+=kdr[i-1];
		
		while(q--){
			ll x;cin>>x;
			x = min(x,200001LL);
			ll ans = 0;
			if(dp[x]==-1){
				for(ll i = 0;i<=mx;i+=x){
					ll totCnt = cnt[i+x-1]-cnt[i];
					ll sum = pre[i+x-1]-pre[i];
					ll sqr = kdr[i+x-1]-kdr[i];
					
					ll tmp = sqr + totCnt * (i*i) - 2*i*(sum);
					ans += tmp;
					//cout<<i<<" --> "<<sum<<" "<<sqr<<" "<<nx<<" = "<<tmp<<endl;
				}
				
				dp[x]=ans;
			}else ans = dp[x];
			
			cout<<ans<<endl;
		}
	}
	return 0;
}


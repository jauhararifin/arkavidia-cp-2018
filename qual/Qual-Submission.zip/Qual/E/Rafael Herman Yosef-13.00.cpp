#include<stdio.h>
#include<sstream>
#include<iostream>

#include<math.h>
#include<algorithm>
#include<utility>
#include<string.h>
#include<string>
#include<stdlib.h>
#include<assert.h>
#include<time.h>

#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>

#define FI first
#define SE second
#define PB push_back
#define MP make_pair
#define endl '\n'
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

void desperate_optimization(int precision){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(precision);
}

ll ctr[400015];
ll pref[400015];
ll finals[400015];
ll rctr[400015];
ll sum[400015];

int main(){
	desperate_optimization(10);
	int ntc;
	cin>>ntc;
	while(ntc--){
		int n,q;
		cin>>n>>q;
		ll maxi = 0;
		pref[0] = sum[0] = rctr[0] = 0;
		for(int i=0;i<=400005;i++) ctr[i] = 0,finals[i] = -1;
		for(int i=1;i<=n;i++){
			ll x;
			cin>>x;
			maxi = max(maxi,x);
			ctr[x]++;
		}
		for(ll i=1;i<=400005;i++){
			pref[i] = pref[i-1] + i * i * ctr[i]; //A^2
			rctr[i] = rctr[i-1] + ctr[i]; // x
			sum[i] = sum[i-1] + 2 * i * ctr[i]; // 2A
		}
		while(q--){
			ll mod;
			cin>>mod;
			ll re = 0;
			if(mod > maxi) re = pref[maxi];
			else if(finals[mod] != -1) re = finals[mod];
			else{
				ll vt = 0;
				for(ll i=0;i<=maxi;i += mod){
					ll d1 = pref[i + mod - 1];
					ll d2 = rctr[i + mod - 1];
					ll d3 = sum[i + mod - 1];
					ll b1 = 0;
					ll b2 = 0;
					ll b3 = 0;
					if(i != 0){
						b1 = pref[i-1];
						b2 = rctr[i-1];
						b3 = sum[i-1];
					}
					re += ((d1 - b1) + ((d2 - b2) * vt * vt - (d3 - b3) * vt));
					vt += mod;
				}
				finals[mod] = re;
			}
			cout<<re<<endl;
		}
	}
	return 0;
}


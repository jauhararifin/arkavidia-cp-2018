#include <bits/stdc++.h>
#define INF 1e9+7
#define pf2 pop_front
#define pb2 pop_back
#define pb push_back
#define pf push_front
#define fi first
#define se second
#define sz size
#define eps 1e-7
#define fod find_by_order
#define fastio ios::sync_with_stdio(0);cin.tie(NULL);cout.tie(NULL);
#define ofk order_of_key
#define val(x) cout << "Value dari "<< #x << " adalah " << x  << "\n"
#define tr tree<int,null_type,less<int>,rb_tree_tag,tree_order_statistics_node_update>
typedef long long ll;
using namespace std;

int dx[8] = {1,0,-1,0,1,1,-1,-1};
int dy[8] = {0,1,0,-1,1,-1,1,-1};

#define MOD 1000000007

ll power(ll x,ll y, ll p){ll res = 1;x = x % MOD;  while (y > 0){ if (y & 1) res = (res*x) % MOD; y = y>>1;  x = (x*x) % p;  }return res;}

void readf(string x){
	freopen((x+".in").c_str(),"r",stdin);
	freopen((x+".out").c_str(),"w",stdout);
}

void pr(string x){
	freopen((x+".in").c_str(),"w",stdout);
}


int read()
{
	bool min = 0;
	int  result = 0;
	char ch;
	ch = getchar();
	while(1)
	{
		if(ch == '-') break;
		if(ch >='0' && ch <= '9') break;
		ch = getchar();
	}
	if(ch == '-') min = 1;else result = ch-'0';
	while(1)
	{
		ch =getchar();
		if(ch< '0' || ch>'9') break;
		result = result * 10 + (ch-'0');
	}
	if(min) return -result;
	return result;
}
//Reynaldo's Template

const int n = 2e5 + 5;

int main(){
	fastio
	int TC;
	cin >> TC;
	while (TC--){
		ll N,Q;
		cin >> N >> Q;
		ll x[N+5];
		ll pref[2*n],cnt[2*n],prefk[2*n];
		memset(pref,0,sizeof pref);memset(cnt,0,sizeof cnt); memset(prefk,0,sizeof prefk);
		for(int i=1;i<=N;i++){
			cin >> x[i];
			pref[x[i]] += x[i];
			prefk[x[i]] += x[i] * x[i];
			cnt[x[i]]++;
		}
		for(int i=1;i<2*n;i++){
			pref[i] += pref[i-1];
			prefk[i] += prefk[i-1];
			cnt[i] += cnt[i-1];
		}
		ll ans[n];
		memset(ans,0,sizeof ans);
		for(ll i=2;i<n;i++){
			for(ll j=0;j<n;j+=i){
				ll ki = j, ka = j + i -1;
				ans[i] +=  prefk[ka] - prefk[ki];
				ans[i] += ki*ki*(cnt[ka]-cnt[ki]);
				ans[i] -= (pref[ka]- pref[ki]) * 2  * ki;
			}
		}
		while(Q--){
			int a;
			cin >> a;
			if(a >= n) {
				cout << prefk[n-1] << "\n";
			}
			else{
				if(a == 1) cout << 0 << "\n";
				else
				cout << ans[a] << "\n";
			}
		}
		
	}
}

